# Standard Library `log` Instrumentation

This document explains how the `log` package instrumentation provided by this repository works.

## Overview

`instrumentation/log` hooks `log.(*Logger).Output` to append `trace_id`/`span_id` to log output when an active span is available.

## How trace/span ids are attached

The hook calls `runtime.GetTraceAndSpanID()` (see `pkg/runtime/trace_context.go`), which returns the current goroutine's active trace/span id from goroutine-local storage (GLS), or two empty strings if none is available. If the returned trace id is empty, the log line is left unchanged.

`GetTraceAndSpanID()` only returns real data once `go.opentelemetry.io/otel/sdk/trace`'s own instrumentation (`instrumentation/go.opentelemetry.io/otel/sdk/trace`) has registered its implementation via `runtime.RegisterTraceAndSpanIDFunc`. That registration only happens when `go.opentelemetry.io/otel/sdk/trace` is applied — which, in turn, requires the package to be part of the application's build graph.

## Limitation: `go.opentelemetry.io/otel/sdk/trace` must be in the build graph

**`go.opentelemetry.io/otel/sdk/trace` must already be part of the application's build dependency graph (as seen by `go list -deps` / `go build -a -x -n`) for this instrumentation to inject `trace_id`/`span_id`.**

Instrumentation imports declared in an `otel.instrumentation.go` file are tracked in `go.mod` but are intentionally **not** added to the build's dependency graph — that file is marked with the `//go:build tools` build tag specifically so instrumentation imports do not become build dependencies themselves. So relying on `log`'s own instrumentation module to pull in `sdk/trace` does not work.

In practice, this means your application must construct a real `sdk/trace.TracerProvider` somewhere in its own source (for example via `sdktrace.NewTracerProvider(...)` and `otel.SetTracerProvider(...)`), even if you don't otherwise call the SDK directly. Without that, spans are still created and exported correctly, but `log` output will not carry `trace_id`/`span_id`.

If `go.opentelemetry.io/otel/sdk/trace` instrumentation was not applied (for example because the package was not present in the application's build graph), or if there is no active span in GLS, the original log output is left unchanged — see [`instrumentation/go.opentelemetry.io/otel`'s README](../go.opentelemetry.io/otel/README.md) for how GLS is populated.

// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package server

import (
	"context"
	"log/slog"
	"net/http"
	"strconv"
	"sync"
	"time"

	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/metric"
	"go.opentelemetry.io/otel/propagation"
	otelsemconv "go.opentelemetry.io/otel/semconv/v1.37.0"
	"go.opentelemetry.io/otel/trace"

	httpsemconv "go.opentelemetry.io/otelc/instrumentation/net/http/semconv"
	"go.opentelemetry.io/otelc/pkg/hook"
	"go.opentelemetry.io/otelc/pkg/runtime"
)

const (
	instrumentationName = "go.opentelemetry.io/otelc/instrumentation/net/http"
	instrumentationKey  = "NETHTTP"
	responseWriterIndex = 1
	requestIndex        = 2
)

var (
	logger     = runtime.Logger()
	tracer     trace.Tracer
	propagator propagation.TextMapPropagator
	metrics    httpsemconv.HTTPServer
	initOnce   sync.Once
)

func initInstrumentation() {
	initOnce.Do(func() {
		version := runtime.ModuleVersion()
		tracer = otel.GetTracerProvider().Tracer(
			instrumentationName,
			trace.WithInstrumentationVersion(version),
		)
		propagator = otel.GetTextMapPropagator()
		meter := otel.GetMeterProvider().Meter(
			instrumentationName,
			metric.WithInstrumentationVersion(version),
			metric.WithSchemaURL(otelsemconv.SchemaURL),
		)
		metrics = httpsemconv.NewHTTPServer(meter)
		logger.Info("HTTP server instrumentation initialized")
	})
}

// debugEnabled gates per-request Debug calls: slog evaluates arguments before
// checking the level, so an unguarded call pays for r.URL.String() and
// attribute boxing on every request even when debug logging is off.
func debugEnabled() bool {
	return logger.Enabled(context.Background(), slog.LevelDebug)
}

// netHttpServerEnabler controls whether server instrumentation is enabled
type netHttpServerEnabler struct{}

func (n netHttpServerEnabler) Enable() bool {
	return runtime.Instrumented(instrumentationKey)
}

var serverEnabler = netHttpServerEnabler{}

// hookData carries span state from BeforeServeHTTP to AfterServeHTTP. A typed
// struct instead of SetKeyData's map[string]interface{} keeps the per-request
// cost to a single small allocation with no map or string hashing.
type hookData struct {
	ctx               context.Context
	req               *http.Request
	span              trace.Span
	start             time.Time
	activeMetricAttrs attribute.Set
}

func BeforeServeHTTP(ictx hook.HookContext, recv interface{}, w http.ResponseWriter, r *http.Request) {
	// This runs once per request; keep the disabled path free of logging.
	if !serverEnabler.Enable() {
		return
	}

	initInstrumentation()

	if debugEnabled() {
		logger.Debug("BeforeServeHTTP called",
			"method", r.Method,
			"url", r.URL.String(),
			"remote_addr", r.RemoteAddr)
	}

	// Extract trace context from incoming request headers
	ctx := propagator.Extract(r.Context(), propagation.HeaderCarrier(r.Header))

	// Get trace attributes from semconv
	attrs := httpsemconv.HTTPServerRequestTraceAttrs("", r)

	// Route isn't known until ServeMux matches. AfterServeHTTP renames the span.
	spanName := httpsemconv.HTTPServerSpanName(r.Method, "")

	// Start span
	ctx, span := tracer.Start(ctx,
		spanName,
		trace.WithSpanKind(trace.SpanKindServer),
		trace.WithAttributes(attrs...),
	)

	// Wrap ResponseWriter to capture status code
	wrapper := &writerWrapper{
		ResponseWriter: w,
		statusCode:     http.StatusOK,
	}
	ictx.SetParam(responseWriterIndex, wrapper)

	// Update request with new context containing the span
	newReq := r.WithContext(ctx)
	ictx.SetParam(requestIndex, newReq)

	activeMetricAttrs := attribute.NewSet(metrics.ActiveRequestMetricAttributes("", r, nil)...)
	metrics.AddActiveRequests(ctx, 1, activeMetricAttrs)

	// Store data for after hook
	ictx.SetData(&hookData{
		ctx:               ctx,
		req:               r,
		span:              span,
		start:             time.Now(),
		activeMetricAttrs: activeMetricAttrs,
	})
}

func AfterServeHTTP(ictx hook.HookContext) {
	data, ok := ictx.GetData().(*hookData)
	if !ok || data == nil || data.span == nil {
		logger.Debug("AfterServeHTTP: no span from before hook")
		return
	}
	initInstrumentation()

	ctx := data.ctx
	if ctx == nil {
		ctx = context.Background()
	}
	defer metrics.AddActiveRequests(ctx, -1, data.activeMetricAttrs)

	span := data.span
	defer span.End()

	// ServeMux fills in r.Pattern on the same request after the span was created.
	// Stays empty for routers that name the span themselves (gin, chi).
	route := ""
	if r, ok := ictx.GetParam(requestIndex).(*http.Request); ok && r != nil {
		route = httpsemconv.HTTPRoute(r.Pattern)
		if route != "" && span.IsRecording() {
			span.SetName(httpsemconv.HTTPServerSpanName(r.Method, route))
			span.SetAttributes(httpsemconv.HTTPServerRoute(route))
		}
	}

	// Extract status code from wrapped ResponseWriter
	statusCode := http.StatusOK
	responseSize := int64(0)
	if p, ok := ictx.GetParam(responseWriterIndex).(http.ResponseWriter); ok {
		if wrapper, ok := p.(*writerWrapper); ok {
			statusCode = wrapper.statusCode
			// net/http discards body writes for HEAD requests, so none reach the client.
			if data.req == nil || data.req.Method != http.MethodHead {
				responseSize = wrapper.written
			}
		}
	}

	// Add response attributes
	attrs := httpsemconv.HTTPServerResponseTraceAttrs(statusCode, responseSize)
	span.SetAttributes(attrs...)

	// Set span status based on status code
	code, desc := httpsemconv.HTTPServerStatus(statusCode)
	if code != codes.Unset {
		span.SetStatus(code, desc)
	}

	if req := data.req; req != nil {
		metricAttrs := []attribute.KeyValue(nil)
		if statusCode >= 500 && statusCode < 600 {
			metricAttrs = append(metricAttrs, otelsemconv.ErrorTypeKey.String(strconv.Itoa(statusCode)))
		}
		metrics.RecordMetrics(
			ctx,
			"",
			req,
			statusCode,
			route,
			req.ContentLength,
			responseSize,
			time.Since(data.start).Seconds(),
			metricAttrs,
		)
	}

	if debugEnabled() {
		logger.Debug("AfterServeHTTP called",
			"status_code", statusCode,
			"duration_ms", time.Since(data.start).Milliseconds())
	}
}

// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package server

import (
	"bufio"
	"io"
	"net"
	"net/http"
)

// Compile-time assertions that writerWrapper satisfies the optional interfaces
// an http.ResponseWriter may implement.
var (
	_ http.ResponseWriter                       = (*writerWrapper)(nil)
	_ http.Hijacker                             = (*writerWrapper)(nil)
	_ http.Flusher                              = (*writerWrapper)(nil)
	_ http.Pusher                               = (*writerWrapper)(nil)
	_ io.ReaderFrom                             = (*writerWrapper)(nil)
	_ io.StringWriter                           = (*writerWrapper)(nil)
	_ interface{ Unwrap() http.ResponseWriter } = (*writerWrapper)(nil)
)

// writerWrapper wraps http.ResponseWriter to capture the status code and the
// number of response body bytes written.
type writerWrapper struct {
	http.ResponseWriter
	statusCode  int
	wroteHeader bool
	written     int64
}

// WriteHeader captures the final status code and forwards to the underlying ResponseWriter.
func (w *writerWrapper) WriteHeader(statusCode int) {
	if w.wroteHeader {
		return
	}

	// Informational responses do not commit the final response. Switching
	// protocols is the exception: net/http treats 101 as final.
	if statusCode >= 100 && statusCode <= 199 && statusCode != http.StatusSwitchingProtocols {
		w.ResponseWriter.WriteHeader(statusCode)
		return
	}

	w.statusCode = statusCode
	w.wroteHeader = true
	w.ResponseWriter.WriteHeader(statusCode)
}

// Write implements http.ResponseWriter.Write and ensures WriteHeader is called
func (w *writerWrapper) Write(b []byte) (int, error) {
	// If WriteHeader wasn't called yet, call it with 200 OK (default HTTP behavior)
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}
	n, err := w.ResponseWriter.Write(b)
	w.written += int64(n)
	return n, err
}

// writeOnly hides every method of the wrapped value except Write, so that
// io.Copy cannot re-enter a ReadFrom fast path through it.
type writeOnly struct {
	io.Writer
}

// ReadFrom implements io.ReaderFrom so that io.Copy keeps reaching the
// underlying ResponseWriter's own ReadFrom. net/http's *response implements
// io.ReaderFrom and hands the body to the connection, which lets the kernel
// serve it with sendfile(2). Without this method the wrapper hides that
// capability from io.Copy, and http.ServeFile/http.ServeContent silently fall
// back to a 32KiB user-space copy loop on every instrumented server.
func (w *writerWrapper) ReadFrom(src io.Reader) (int64, error) {
	// http.ResponseWriter.Write implies a 200 when no status was set; ReadFrom
	// writes the body the same way, so record it before handing the body off.
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}

	if rf, ok := w.ResponseWriter.(io.ReaderFrom); ok {
		n, err := rf.ReadFrom(src)
		w.written += n
		return n, err
	}

	// The underlying writer has no fast path, so fall back to a plain copy
	// through Write, which counts the bytes. writeOnly keeps io.Copy from
	// picking this method up again.
	return io.Copy(writeOnly{w}, src)
}

// WriteString implements io.StringWriter so that io.WriteString keeps
// reaching the underlying ResponseWriter's own WriteString. net/http's
// *response implements io.StringWriter to write the string without an extra
// []byte conversion. Without this method io.WriteString falls back to
// converting to []byte and calling Write, which is the same fast-path loss
// ReadFrom fixes above, just for string writes instead of io.Copy.
func (w *writerWrapper) WriteString(s string) (int, error) {
	// http.ResponseWriter.Write implies a 200 when no status was set;
	// WriteString writes the body the same way, so record it first.
	if !w.wroteHeader {
		w.WriteHeader(http.StatusOK)
	}

	if sw, ok := w.ResponseWriter.(io.StringWriter); ok {
		n, err := sw.WriteString(s)
		w.written += int64(n)
		return n, err
	}

	// The underlying writer has no fast path, so fall back to a plain Write.
	n, err := w.ResponseWriter.Write([]byte(s))
	w.written += int64(n)
	return n, err
}

// Hijack implements the http.Hijacker interface
func (w *writerWrapper) Hijack() (net.Conn, *bufio.ReadWriter, error) {
	if h, ok := w.ResponseWriter.(http.Hijacker); ok {
		return h.Hijack()
	}
	return nil, nil, http.ErrNotSupported
}

// FlushError is preferred by http.ResponseController over http.Flusher.
func (w *writerWrapper) FlushError() error {
	fe, hasFlushError := w.ResponseWriter.(interface{ FlushError() error })
	f, isFlusher := w.ResponseWriter.(http.Flusher)
	if !hasFlushError && !isFlusher {
		return http.ErrNotSupported
	}

	if hasFlushError {
		if err := fe.FlushError(); err != nil {
			return err
		}
	} else {
		f.Flush()
	}

	// Flushing commits the response, and net/http sends a 200 when no status
	// was set. Record it directly on the wrapper so a later WriteHeader does
	// not replace it on the span or forward a superfluous WriteHeader call to
	// the underlying writer, which has already committed headers.
	if !w.wroteHeader {
		w.wroteHeader = true
		w.statusCode = http.StatusOK
	}

	return nil
}

// Flush implements the http.Flusher interface
func (w *writerWrapper) Flush() {
	_ = w.FlushError()
}

// Push implements the http.Pusher interface, forwarding to the underlying
// ResponseWriter when it supports HTTP/2 server push and returning
// http.ErrNotSupported otherwise.
func (w *writerWrapper) Push(target string, opts *http.PushOptions) error {
	if pusher, ok := w.ResponseWriter.(http.Pusher); ok {
		return pusher.Push(target, opts)
	}
	return http.ErrNotSupported
}

// Unwrap exposes the underlying writer to http.ResponseController.
func (w *writerWrapper) Unwrap() http.ResponseWriter {
	return w.ResponseWriter
}

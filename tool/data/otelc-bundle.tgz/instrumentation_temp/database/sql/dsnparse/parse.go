// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package dsnparse

import (
	"net"
	nurl "net/url"
	"strings"
	"sync"
)

// DSNInfo holds the parsed server address components and database name from a
// data source name. Host is the bare host: IPv6 literals are stored without
// their surrounding brackets, matching the `server.address` semantic
// convention.
type DSNInfo struct {
	Host   string
	Port   string
	DBName string
}

// Addr returns the host:port pair. When Port is empty only the host is
// returned.
//
// The result is consumed by semconv helpers that split it back apart with
// net.SplitHostPort, so an IPv6 host has to be bracketed or the round trip
// loses both attributes: "::1"+"3306" joined naively gives "::1:3306", which
// is itself a valid IPv6 address, leaving no way to tell the port back out.
// net.JoinHostPort brackets only when it needs to.
//
// The host is normalised here rather than trusted, because DSNInfo is exported
// and parsers registered through RegisterDSNParser may hand back a host that
// still has its brackets (net/url's u.Host does, u.Hostname() does not).
func (d DSNInfo) Addr() string {
	host := trimHostBrackets(d.Host)
	if host == "" {
		return ""
	}
	if d.Port == "" {
		return host
	}
	return net.JoinHostPort(host, d.Port)
}

// trimHostBrackets removes the surrounding brackets from an IPv6 literal so
// Host stays bare regardless of which DSN dialect it came from. Parsers built
// on net/url get this from u.Hostname(); the hand-rolled key=value and Oracle
// paths call it explicitly. A host never legitimately carries brackets
// otherwise, so this is safe to apply unconditionally.
func trimHostBrackets(host string) string {
	if len(host) > 1 && host[0] == '[' && host[len(host)-1] == ']' {
		return host[1 : len(host)-1]
	}
	return host
}

// DSNParser parses a driver-specific data source name into structured
// connection information. Implementations must never panic; they return a
// zero-value DSNInfo when the DSN cannot be understood.
type DSNParser interface {
	Parse(dsn string) DSNInfo
}

// DSNParserFunc is an adapter that lets an ordinary function satisfy DSNParser.
type DSNParserFunc func(dsn string) DSNInfo

// Parse calls f(dsn).
func (f DSNParserFunc) Parse(dsn string) DSNInfo { return f(dsn) }

// registry holds DSNParser implementations indexed by driver name. It is safe
// for concurrent use, so parsers may be registered from init() functions while
// ParseDSN runs inside instrumentation hooks.
type registry struct {
	mu      sync.RWMutex
	parsers map[string]DSNParser
}

func (r *registry) register(driverName string, parser DSNParser) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.parsers[driverName] = parser
}

func (r *registry) registerAll(parsers map[string]DSNParser) {
	r.mu.Lock()
	defer r.mu.Unlock()
	for name, p := range parsers {
		r.parsers[name] = p
	}
}

func (r *registry) lookup(driverName string) (DSNParser, bool) {
	r.mu.RLock()
	defer r.mu.RUnlock()
	p, ok := r.parsers[driverName]
	return p, ok
}

// defaultRegistry maps the built-in driver names to their parsers. Aliases that
// share a wire format (e.g. pgx and lib/pq both speak the PostgreSQL DSN
// format) point at the same parser.
var defaultRegistry = &registry{
	parsers: map[string]DSNParser{
		"postgres":   DSNParserFunc(parsePostgresDSN),
		"postgresql": DSNParserFunc(parsePostgresDSN),
		"pgx":        DSNParserFunc(parsePostgresDSN),
		"lib/pq":     DSNParserFunc(parsePostgresDSN),
		"mysql":      DSNParserFunc(parseMySQLDSN),
		"mariadb":    DSNParserFunc(parseMySQLDSN),
		"sqlite3":    DSNParserFunc(parseSQLiteDSN),
		"sqlite":     DSNParserFunc(parseSQLiteDSN),
		"sqlserver":  DSNParserFunc(parseSQLServerDSN),
		"mssql":      DSNParserFunc(parseSQLServerDSN),
		"clickhouse": DSNParserFunc(parseClickHouseDSN),
		"godror":     DSNParserFunc(parseOracleDSN),
		"oracle":     DSNParserFunc(parseOracleDSN),
		"oci8":       DSNParserFunc(parseOracleDSN),
		"go-oci8":    DSNParserFunc(parseOracleDSN),
	},
}

// RegisterDSNParser registers a custom DSN parser for driverName. Built-in
// parsers are registered automatically; registering an already-known name
// overwrites the previous parser. It is safe to call from init().
func RegisterDSNParser(driverName string, parser DSNParser) {
	defaultRegistry.register(driverName, parser)
}

// RegisterDSNParsers registers multiple DSN parsers under a single lock. Prefer
// it over repeated RegisterDSNParser calls when registering several at once.
func RegisterDSNParsers(parsers map[string]DSNParser) {
	defaultRegistry.registerAll(parsers)
}

// ParseDSN parses a driver-specific data source name and returns structured
// connection information. Registered drivers use their dedicated parser;
// unregistered drivers fall back to a best-effort URL parse rather than
// silently yielding an empty address. It never panics.
func ParseDSN(driverName, dsn string) DSNInfo {
	if parser, ok := defaultRegistry.lookup(driverName); ok {
		return parser.Parse(dsn)
	}
	return bestEffortParse(dsn)
}

// bestEffortParse extracts connection info from a DSN using standard URL
// parsing. It is the fallback for drivers without a registered parser and
// returns a zero-value DSNInfo when the DSN is not URL-shaped.
func bestEffortParse(dsn string) DSNInfo {
	if u, err := nurl.Parse(dsn); err == nil && u.Host != "" {
		return DSNInfo{
			Host:   u.Hostname(),
			Port:   u.Port(),
			DBName: strings.TrimPrefix(u.Path, "/"),
		}
	}
	return DSNInfo{}
}

// ParseDbName extracts the database name from a generic DSN by finding the
// last '/' and trimming any query-string suffix. Retained for backward
// compatibility; prefer ParseDSN when the driver name is known.
func ParseDbName(dsn string) string {
	for i := len(dsn) - 1; i >= 0; i-- {
		if dsn[i] == '/' {
			dbname := dsn[i+1:]
			if idx := strings.IndexAny(dbname, "?&"); idx >= 0 {
				dbname = dbname[:idx]
			}
			if unesc, err := nurl.PathUnescape(dbname); err == nil {
				return unesc
			}
			return dbname
		}
	}
	return ""
}

// LegacyParseDSN wraps ParseDSN and preserves the original (addr, error) shape
// used by the db package's beforeOpenInstrumentation.
func LegacyParseDSN(driverName, dsn string) (string, error) {
	info := ParseDSN(driverName, dsn)
	if addr := info.Addr(); addr != "" {
		return addr, nil
	}
	return driverName, nil
}

// ---- PostgreSQL ---------------------------------------------------------------

// parsePostgresDSN handles both RFC 3986 URL format and the PostgreSQL libpq
// key=value connection string format.
//
// URL examples:
//
//	postgres://user:pass@host:5432/mydb
//	postgresql://host/mydb
//
// Key-value examples:
//
//	host=localhost port=5432 dbname=mydb
//	host='db.example.com' port=5432 dbname=prod user=alice
func parsePostgresDSN(dsn string) DSNInfo {
	if strings.Contains(dsn, "://") {
		if u, err := nurl.Parse(dsn); err == nil &&
			(u.Scheme == "postgres" || u.Scheme == "postgresql") {
			host := u.Hostname()
			port := u.Port()
			if port == "" {
				port = "5432"
			}
			dbName := strings.TrimPrefix(u.Path, "/")
			return DSNInfo{Host: host, Port: port, DBName: dbName}
		}
	}
	return parseLibpqKV(dsn)
}

// parseLibpqKV parses the PostgreSQL libpq keyword=value connection string.
// Values may be unquoted (terminated by whitespace) or single-quoted (with
// backslash escape support inside quotes).
func parseLibpqKV(dsn string) DSNInfo {
	info := DSNInfo{Host: "localhost", Port: "5432"}
	rest := strings.TrimSpace(dsn)
	for len(rest) > 0 {
		rest = strings.TrimLeft(rest, " \t\n\r")
		if rest == "" {
			break
		}
		eqIdx := strings.IndexByte(rest, '=')
		if eqIdx < 0 {
			break
		}
		key := strings.TrimSpace(rest[:eqIdx])
		rest = rest[eqIdx+1:]

		var val string
		if strings.HasPrefix(rest, "'") {
			rest = rest[1:]
			var b strings.Builder
			for len(rest) > 0 {
				switch {
				case rest[0] == '\\' && len(rest) > 1:
					b.WriteByte(rest[1])
					rest = rest[2:]
				case rest[0] == '\'':
					rest = rest[1:]
					val = b.String()
					goto nextKV
				default:
					b.WriteByte(rest[0])
					rest = rest[1:]
				}
			}
			val = b.String()
		} else {
			end := strings.IndexAny(rest, " \t\n\r")
			if end < 0 {
				end = len(rest)
			}
			val = rest[:end]
			rest = rest[end:]
		}
	nextKV:
		switch key {
		case "host":
			info.Host = trimHostBrackets(val)
		case "port":
			info.Port = val
		case "dbname":
			info.DBName = val
		}
	}
	return info
}

// ---- MySQL -------------------------------------------------------------------

// parseMySQLDSN handles the go-sql-driver/mysql DSN format:
//
//	[user[:password]@][protocol[(address)]]/dbname[?params]
//
// It also handles the non-standard form where the address is not wrapped in
// parentheses (e.g. user:pass@tcp:3306/dbname or user:pass@host:3306/dbname).
func parseMySQLDSN(dsn string) DSNInfo {
	// Find the last @ that precedes the first '(' so we skip '@' inside passwords.
	atIdx := -1
	for i := 0; i < len(dsn); i++ {
		if dsn[i] == '@' {
			atIdx = i
		}
		if dsn[i] == '(' {
			break
		}
	}
	rest := dsn
	if atIdx >= 0 {
		rest = dsn[atIdx+1:]
	}

	var addrStr, dbPart string

	if lp := strings.IndexByte(rest, '('); lp >= 0 {
		// Standard parenthesised address: proto(host:port)/dbname
		if rp := strings.IndexByte(rest[lp:], ')'); rp >= 0 {
			addrStr = rest[lp+1 : lp+rp]
			dbPart = rest[lp+rp+1:]
		}
	} else {
		// Non-standard: no parentheses around the address.
		// Locate the '/' that separates the address from the database name.
		// A unix-socket address is itself an absolute filesystem path and so
		// contains '/' before the database name does, meaning the first '/'
		// belongs to the address, not the separator. Every other form here
		// (tcp, bare host, bare port) has no '/' in the address at all, so
		// using the last '/' there gives the same split as the first.
		sep := strings.IndexByte
		searchIn := rest
		if isMySQLUnixAddr(rest) {
			sep = strings.LastIndexByte
			if q := strings.IndexByte(rest, '?'); q >= 0 {
				searchIn = rest[:q]
			}
		}
		if sl := sep(searchIn, '/'); sl >= 0 {
			addrStr = rest[:sl]
			dbPart = rest[sl:]
		} else {
			addrStr = rest
		}
		addrStr = mysqlStripProtocol(addrStr)
	}

	host, port := mysqlSplitAddr(addrStr)
	dbName := mysqlDBName(dbPart)
	return DSNInfo{Host: host, Port: port, DBName: dbName}
}

// isMySQLUnixAddr reports whether a non-parenthesized MySQL address begins
// with the "unix:" protocol keyword, meaning what follows the colon is a
// filesystem path rather than a host[:port].
func isMySQLUnixAddr(addr string) bool {
	colon := strings.IndexByte(addr, ':')
	return colon >= 0 && addr[:colon] == "unix"
}

// mysqlKnownProtocols lists the transport keywords used by go-sql-driver/mysql.
var mysqlKnownProtocols = map[string]bool{
	"tcp": true, "unix": true, "udp": true, "pipe": true,
}

// mysqlStripProtocol removes a leading "proto:" prefix when proto is a known
// MySQL transport keyword, normalising a bare port number to "localhost:port".
func mysqlStripProtocol(addr string) string {
	colon := strings.IndexByte(addr, ':')
	if colon < 0 {
		return addr
	}
	proto := addr[:colon]
	if !mysqlKnownProtocols[proto] {
		return addr
	}
	rest := addr[colon+1:]
	if rest == "" {
		return ""
	}
	// If rest is pure digits it is just a port number with an implicit localhost.
	allDigits := true
	for _, c := range rest {
		if c < '0' || c > '9' {
			allDigits = false
			break
		}
	}
	if allDigits {
		return "localhost:" + rest
	}
	return rest
}

// mysqlSplitAddr splits a "host:port" string, defaulting to port 3306 when no
// port is present. IPv6 addresses enclosed in brackets are handled correctly.
func mysqlSplitAddr(addr string) (host, port string) {
	if addr == "" {
		return "", ""
	}
	if strings.HasPrefix(addr, "[") {
		if rb := strings.LastIndexByte(addr, ']'); rb >= 0 {
			host = addr[1:rb]
			rest := addr[rb+1:]
			if strings.HasPrefix(rest, ":") {
				return host, rest[1:]
			}
			return host, "3306"
		}
	}
	if colon := strings.LastIndexByte(addr, ':'); colon >= 0 {
		return addr[:colon], addr[colon+1:]
	}
	// Unix socket paths contain '/' but no port.
	if strings.ContainsRune(addr, '/') {
		return addr, ""
	}
	return addr, "3306"
}

// mysqlDBName trims the leading '/' and any query string from a dbname segment.
func mysqlDBName(s string) string {
	s = strings.TrimPrefix(s, "/")
	if i := strings.IndexByte(s, '?'); i >= 0 {
		s = s[:i]
	}
	return s
}

// ---- SQLite ------------------------------------------------------------------

// parseSQLiteDSN handles sqlite3 / sqlite DSN strings. SQLite is always
// file-local, so Host and Port are not populated. DBName is set to the
// filename (or ":memory:" for in-memory databases).
func parseSQLiteDSN(dsn string) DSNInfo {
	return DSNInfo{Host: "sqlite3", DBName: sqliteDBName(dsn)}
}

// sqliteDBName extracts the database name from a SQLite DSN. It handles
// file: URI schemes, the :memory: shorthand, and bare filenames.
func sqliteDBName(dsn string) string {
	if strings.HasPrefix(dsn, "file:") {
		path := dsn[len("file:"):]
		if i := strings.IndexByte(path, '?'); i >= 0 {
			path = path[:i]
		}
		bare := strings.TrimPrefix(path, "//")
		if bare == ":memory:" {
			return ":memory:"
		}
		if i := strings.LastIndexByte(path, '/'); i >= 0 {
			return path[i+1:]
		}
		return path
	}
	if dsn == ":memory:" {
		return ":memory:"
	}
	if i := strings.IndexByte(dsn, '?'); i >= 0 {
		dsn = dsn[:i]
	}
	if i := strings.LastIndexByte(dsn, '/'); i >= 0 {
		return dsn[i+1:]
	}
	return dsn
}

// ---- SQL Server --------------------------------------------------------------

// parseSQLServerDSN handles SQL Server DSNs in both URL format and the
// ADO.NET semicolon-delimited key=value connection-string format.
//
// URL examples:
//
//	sqlserver://user:pass@host:1433?database=mydb
//	mssql://host:1433?database=mydb
//
// ADO.NET examples:
//
//	server=host;port=1433;database=mydb;user id=sa;password=secret
//	Server=host,1433;Database=mydb;User Id=sa;Password=secret
func parseSQLServerDSN(dsn string) DSNInfo {
	if strings.Contains(dsn, "://") {
		if u, err := nurl.Parse(dsn); err == nil {
			host := u.Hostname()
			port := u.Port()
			if port == "" {
				port = "1433"
			}
			dbName := u.Query().Get("database")
			return DSNInfo{Host: host, Port: port, DBName: dbName}
		}
	}
	return parseSQLServerKV(dsn)
}

// parseSQLServerKV parses the ADO.NET semicolon-delimited key=value format.
// The server value may carry the "tcp:" transport prefix, which is not part of
// the address.
func parseSQLServerKV(dsn string) DSNInfo {
	var host, port, dbName string
	for _, pair := range strings.Split(dsn, ";") {
		pair = strings.TrimSpace(pair)
		if pair == "" {
			continue
		}
		key, val, ok := strings.Cut(pair, "=")
		if !ok {
			continue
		}
		key = strings.ToLower(strings.TrimSpace(key))
		val = strings.TrimSpace(val)
		switch key {
		case "server", "data source":
			// Accept "host,port", "host\instance", and the combined
			// "host\instance,port". The port is split off first because the
			// instance name sits between the host and the comma, so a single
			// either/or branch would leave the instance attached to the host
			// whenever a port was also given.
			host = sqlServerStripProtocol(val)
			if comma := strings.IndexByte(host, ','); comma >= 0 {
				port = host[comma+1:]
				host = host[:comma]
			}
			if bs := strings.IndexByte(host, '\\'); bs >= 0 {
				host = host[:bs]
			}
			host = trimHostBrackets(host)
		case "port":
			port = val
		case "database", "initial catalog":
			dbName = val
		}
	}
	if host != "" && port == "" {
		port = "1433"
	}
	return DSNInfo{Host: host, Port: port, DBName: dbName}
}

// tcpPrefix is the transport keyword that selects TCP, in both the ADO.NET and
// the Easy Connect Plus grammars. The others (np:, lpc:) select a different
// transport and are left alone.
const tcpPrefix = "tcp:"

// sqlServerStripProtocol removes a leading "tcp:" from an ADO.NET server
// value, case-insensitively, so the keyword is not reported as the host.
func sqlServerStripProtocol(val string) string {
	if len(val) >= len(tcpPrefix) &&
		strings.EqualFold(val[:len(tcpPrefix)], tcpPrefix) {
		return val[len(tcpPrefix):]
	}
	return val
}

// ---- ClickHouse --------------------------------------------------------------

// parseClickHouseDSN handles ClickHouse DSNs, which are always URL-formatted.
func parseClickHouseDSN(dsn string) DSNInfo {
	u, err := nurl.Parse(dsn)
	if err != nil {
		return DSNInfo{}
	}
	host := u.Hostname()
	port := u.Port()
	if port == "" {
		switch u.Scheme {
		case "http":
			port = "8123"
		case "https":
			port = "8443"
		default: // tcp, native, clickhouse
			port = "9000"
		}
	}
	dbName := strings.TrimPrefix(u.Path, "/")
	if dbName == "" {
		dbName = u.Query().Get("database")
	}
	return DSNInfo{Host: host, Port: port, DBName: dbName}
}

// ---- Oracle ------------------------------------------------------------------

// parseOracleDSN handles Oracle DSNs in URL format or the traditional
// user/pass@host:port/service notation, which may also carry an Easy Connect
// Plus protocol prefix: user/pass@[protocol://]host:port/service.
func parseOracleDSN(dsn string) DSNInfo {
	if strings.Contains(dsn, "://") {
		if u, err := nurl.Parse(dsn); err == nil && u.Host != "" {
			host := u.Hostname()
			port := u.Port()
			if port == "" {
				port = "1521"
			}
			dbName := oracleServiceName(strings.TrimPrefix(u.Path, "/"))
			return DSNInfo{Host: host, Port: port, DBName: dbName}
		}
	}
	atIdx := strings.IndexByte(dsn, '@')
	if atIdx < 0 {
		return DSNInfo{}
	}
	connStr := oracleStripProtocol(dsn[atIdx+1:])
	// Easy Connect parameters start at '?' and are not part of the address.
	if q := strings.IndexByte(connStr, '?'); q >= 0 {
		connStr = connStr[:q]
	}
	var hostPort, dbName string
	if sl := strings.IndexByte(connStr, '/'); sl >= 0 {
		hostPort = connStr[:sl]
		dbName = oracleServiceName(connStr[sl+1:])
	} else {
		hostPort = connStr
	}
	host, port := oracleSplitHostPort(hostPort)
	return DSNInfo{Host: host, Port: port, DBName: dbName}
}

// Easy Connect Plus transport keywords, which may precede the "//" separator.
const oracleTCPSPrefix = "tcps:"

// oracleStripProtocol removes the leading "//" separator, and with it the Easy
// Connect Plus transport keyword tcp or tcps when one precedes it, so the keyword
// is not reported as the host. Any other prefix is left alone.
func oracleStripProtocol(addr string) string {
	prefix, rest, ok := strings.Cut(addr, "//")
	if !ok {
		return addr
	}
	if prefix == "" ||
		strings.EqualFold(prefix, tcpPrefix) ||
		strings.EqualFold(prefix, oracleTCPSPrefix) {
		return rest
	}
	return addr
}

// oracleServiceName returns the service name from the part of an Easy Connect
// string after the host, which may continue with ":server_type" and
// "/instance_name".
func oracleServiceName(s string) string {
	if end := strings.IndexAny(s, ":/"); end >= 0 {
		return s[:end]
	}
	return s
}

func oracleSplitHostPort(hp string) (host, port string) {
	// A bracketed IPv6 literal has colons inside the brackets, so the port
	// separator is only the colon that follows the closing bracket.
	if strings.HasPrefix(hp, "[") {
		if rb := strings.LastIndexByte(hp, ']'); rb >= 0 {
			host = hp[1:rb]
			if rest := hp[rb+1:]; strings.HasPrefix(rest, ":") {
				return host, rest[1:]
			}
			return host, "1521"
		}
	}
	if i := strings.LastIndexByte(hp, ':'); i >= 0 {
		return hp[:i], hp[i+1:]
	}
	return hp, "1521"
}

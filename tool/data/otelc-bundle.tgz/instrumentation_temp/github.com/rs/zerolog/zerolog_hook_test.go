// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package zerolog

import (
	"bytes"
	"encoding/json"
	"testing"

	zerolog "github.com/rs/zerolog"

	"go.opentelemetry.io/otelc/pkg/runtime"
)

func TestBeforeZerologEventMsg_Disabled(t *testing.T) {
	t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", instrumentationKey)

	var output bytes.Buffer
	logger := zerolog.New(&output)
	event := logger.Info()
	BeforeZerologEventMsg(nil, event, "test")
	event.Msg("test")

	var fields map[string]any
	if err := json.Unmarshal(output.Bytes(), &fields); err != nil {
		t.Fatal(err)
	}
	if _, ok := fields[traceIDKey]; ok {
		t.Errorf("disabled instrumentation added %s", traceIDKey)
	}
	if _, ok := fields[spanIDKey]; ok {
		t.Errorf("disabled instrumentation added %s", spanIDKey)
	}
}

func TestBeforeZerologEventMsg_WithTraceContext(t *testing.T) {
	runtime.RegisterTraceAndSpanIDFunc(func() (string, string) {
		return "abc123traceId", "def456spanId"
	})
	defer runtime.RegisterTraceAndSpanIDFunc(func() (string, string) {
		return "", ""
	})

	var output bytes.Buffer
	logger := zerolog.New(&output)
	event := logger.Info()
	BeforeZerologEventMsg(nil, event, "test")
	event.Msg("test")

	var fields map[string]any
	if err := json.Unmarshal(output.Bytes(), &fields); err != nil {
		t.Fatal(err)
	}
	if fields[traceIDKey] != "abc123traceId" {
		t.Errorf("trace ID = %v, want abc123traceId", fields[traceIDKey])
	}
	if fields[spanIDKey] != "def456spanId" {
		t.Errorf("span ID = %v, want def456spanId", fields[spanIDKey])
	}
}

func TestBeforeZerologEventMsg_WithTraceIDOnly(t *testing.T) {
	runtime.RegisterTraceAndSpanIDFunc(func() (string, string) {
		return "abc123traceId", ""
	})
	defer runtime.RegisterTraceAndSpanIDFunc(func() (string, string) {
		return "", ""
	})

	var output bytes.Buffer
	logger := zerolog.New(&output)
	event := logger.Info()
	BeforeZerologEventMsg(nil, event, "test")
	event.Msg("test")

	var fields map[string]any
	if err := json.Unmarshal(output.Bytes(), &fields); err != nil {
		t.Fatal(err)
	}
	if fields[traceIDKey] != "abc123traceId" {
		t.Errorf("trace ID = %v, want abc123traceId", fields[traceIDKey])
	}
	if _, ok := fields[spanIDKey]; ok {
		t.Errorf("trace-only instrumentation added %s", spanIDKey)
	}
}

// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package v9

import (
	"context"
	"errors"
	"net"
	"strings"
	"sync"
	"testing"
	"time"
	"unicode/utf8"

	"github.com/redis/go-redis/v9"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/codes"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"go.opentelemetry.io/otel/sdk/trace/tracetest"
)

func setupTestTracer(t *testing.T) *tracetest.SpanRecorder {
	t.Helper()
	sr := tracetest.NewSpanRecorder()
	tp := sdktrace.NewTracerProvider(sdktrace.WithSpanProcessor(sr))
	otel.SetTracerProvider(tp)
	t.Cleanup(func() { _ = tp.Shutdown(context.Background()) })
	return sr
}

func TestGetRedisV9Statement(t *testing.T) {
	tests := []struct {
		name     string
		cmd      redis.Cmder
		expected string
	}{
		{
			name:     "GET command",
			cmd:      redis.NewCmd(context.Background(), "get", "mykey"),
			expected: "get mykey",
		},
		{
			name:     "SET command with value",
			cmd:      redis.NewCmd(context.Background(), "set", "mykey", "myvalue"),
			expected: "set mykey ?",
		},
		{
			name:     "HSET command",
			cmd:      redis.NewCmd(context.Background(), "hset", "myhash", "field1", "value1"),
			expected: "hset myhash ? ?",
		},
		{
			name:     "DEL command",
			cmd:      redis.NewCmd(context.Background(), "del", "key1", "key2"),
			expected: "del key1 ?",
		},
		{
			name:     "command with nil arg",
			cmd:      redis.NewCmd(context.Background(), "set", nil),
			expected: "set <nil>",
		},
		{
			name:     "command with int arg",
			cmd:      redis.NewCmd(context.Background(), "expire", "mykey", 60),
			expected: "expire mykey ?",
		},
		{
			name:     "command with bool arg true",
			cmd:      redis.NewCmd(context.Background(), "set", "mykey", true),
			expected: "set mykey ?",
		},
		{
			name:     "command with bool arg false",
			cmd:      redis.NewCmd(context.Background(), "set", "mykey", false),
			expected: "set mykey ?",
		},
		{
			name:     "AUTH password",
			cmd:      redis.NewCmd(context.Background(), "auth", "s3cret"),
			expected: "auth ?",
		},
		{
			name:     "AUTH username password",
			cmd:      redis.NewCmd(context.Background(), "auth", "default", "s3cret"),
			expected: "auth ? ?",
		},
		{
			name:     "AUTH mixed case with byte password",
			cmd:      redis.NewCmd(context.Background(), "AUTH", []byte("s3cret")),
			expected: "AUTH ?",
		},
		{
			name:     "HELLO without AUTH",
			cmd:      redis.NewCmd(context.Background(), "hello", 3),
			expected: "hello 3",
		},
		{
			name:     "HELLO AUTH password",
			cmd:      redis.NewCmd(context.Background(), "hello", 3, "auth", "default", "s3cret"),
			expected: "hello 3 auth ? ?",
		},
		{
			name:     "HELLO AUTH then SETNAME",
			cmd:      redis.NewCmd(context.Background(), "hello", 3, "AUTH", "user", "s3cret", "SETNAME", "myclient"),
			expected: "hello 3 AUTH ? ? ? ?",
		},
		{
			name:     "HELLO SETNAME then AUTH",
			cmd:      redis.NewCmd(context.Background(), "hello", 3, "setname", "myclient", "auth", "user", "s3cret"),
			expected: "hello 3 setname myclient auth ? ?",
		},
		{
			name:     "HELLO SETNAME client named auth then AUTH",
			cmd:      redis.NewCmd(context.Background(), "hello", 3, "setname", "auth", "auth", "user", "s3cret"),
			expected: "hello 3 setname auth auth ? ?",
		},
		{
			name:     "AUTH StatusCmd as Auth() sends",
			cmd:      redis.NewStatusCmd(context.Background(), "auth", "s3cret"),
			expected: "auth ?",
		},
		{
			name:     "HELLO MapStringInterfaceCmd as Hello() sends",
			cmd:      redis.NewMapStringInterfaceCmd(context.Background(), "hello", 3, "auth", "default", "s3cret"),
			expected: "hello 3 auth ? ?",
		},
		{
			name:     "HELLO AUTH truncated (missing password)",
			cmd:      redis.NewCmd(context.Background(), "hello", 3, "auth", "user"),
			expected: "hello 3 auth ?",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := getRedisV9Statement(tt.cmd)
			assert.Equal(t, tt.expected, result)
		})
	}
}

func TestGetRedisV9Statement_RedactsCredentials(t *testing.T) {
	tests := []struct {
		name     string
		cmd      redis.Cmder
		expected string
	}{
		{
			name:     "AUTH with password only",
			cmd:      redis.NewCmd(context.Background(), "auth", "s3cret"),
			expected: "auth ?",
		},
		{
			name:     "AUTH with username and password",
			cmd:      redis.NewCmd(context.Background(), "auth", "default", "s3cret"),
			expected: "auth ? ?",
		},
		{
			name:     "AUTH uppercase",
			cmd:      redis.NewCmd(context.Background(), "AUTH", "s3cret"),
			expected: "AUTH ?",
		},
		{
			name:     "HELLO handshake with AUTH",
			cmd:      redis.NewCmd(context.Background(), "hello", 3, "auth", "default", "s3cret"),
			expected: "hello 3 auth ? ?",
		},
		{
			name:     "HELLO AUTH then trailing options",
			cmd:      redis.NewCmd(context.Background(), "hello", 3, "auth", "default", "s3cret", "setname", "myapp"),
			expected: "hello 3 auth ? ? ? ?",
		},
		{
			name:     "HELLO repeated AUTH blocks",
			cmd:      redis.NewCmd(context.Background(), "hello", 3, "auth", "u1", "s3cret1", "auth", "u2", "s3cret2"),
			expected: "hello 3 auth ? ? ? ? ?",
		},
		{
			name:     "HELLO without AUTH is untouched",
			cmd:      redis.NewCmd(context.Background(), "hello", 3),
			expected: "hello 3",
		},
		{
			name:     "key literally named auth is not a credential",
			cmd:      redis.NewCmd(context.Background(), "get", "auth", "token"),
			expected: "get auth ?",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := getRedisV9Statement(tt.cmd)
			assert.Equal(t, tt.expected, result)
			assert.NotContains(t, result, "s3cret", "the password must never reach db.query.text")
		})
	}
}

// TestGetRedisV9Statement_RedactsCommandValues is the regression test for
// https://github.com/open-telemetry/opentelemetry-go-compile-instrumentation/issues/1200:
// by default, db.query.text must never contain the data values applications
// write to Redis, only the command name and (conventionally) the key.
func TestGetRedisV9Statement_RedactsCommandValues(t *testing.T) {
	tests := []struct {
		name     string
		cmd      redis.Cmder
		expected string
	}{
		{
			name:     "SET redacts the value",
			cmd:      redis.NewCmd(context.Background(), "set", "session:42", "s3cret-session-token"),
			expected: "set session:42 ?",
		},
		{
			name:     "HSET redacts field and value",
			cmd:      redis.NewCmd(context.Background(), "hset", "user:42", "email", "alice@example.com"),
			expected: "hset user:42 ? ?",
		},
		{
			name:     "LPUSH redacts every pushed element",
			cmd:      redis.NewCmd(context.Background(), "lpush", "queue", "job1", "job2", "job3"),
			expected: "lpush queue ? ? ?",
		},
		{
			name:     "GET has no value to redact",
			cmd:      redis.NewCmd(context.Background(), "get", "mykey"),
			expected: "get mykey",
		},
		{
			name:     "PING takes no arguments beyond the command name",
			cmd:      redis.NewCmd(context.Background(), "ping"),
			expected: "ping",
		},
		{
			name:     "EVAL redacts script and all arguments",
			cmd:      redis.NewCmd(context.Background(), "eval", "return redis.call('get', KEYS[1])", 1, "key1"),
			expected: "eval ? ? ?",
		},
		{
			name:     "EVAL_RO redacts script and all arguments",
			cmd:      redis.NewCmd(context.Background(), "eval_ro", "return redis.call('get', KEYS[1])", 1, "key1"),
			expected: "eval_ro ? ? ?",
		},
		{
			name:     "EVAL with script containing secret",
			cmd:      redis.NewCmd(context.Background(), "eval", "local token = 's3cret-token'; return token", 0),
			expected: "eval ? ?",
		},
		{
			name:     "ECHO redacts the message",
			cmd:      redis.NewCmd(context.Background(), "echo", "sensitive-message"),
			expected: "echo ?",
		},
		{
			name:     "SLAVEOF redacts host and port",
			cmd:      redis.NewCmd(context.Background(), "slaveof", "10.0.0.1", 6379),
			expected: "slaveof ? ?",
		},
		{
			name:     "REPLICAOF redacts host and port",
			cmd:      redis.NewCmd(context.Background(), "replicaof", "10.0.0.1", 6379),
			expected: "replicaof ? ?",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			result := getRedisV9Statement(tt.cmd)
			assert.Equal(t, tt.expected, result)
		})
	}
}

// TestProcessHook_RedactsCommandValues exercises the full ProcessHook path
// (not just getRedisV9Statement) to confirm the span actually produced for
// an ordinary write command carries no sensitive value in db.query.text.
func TestProcessHook_RedactsCommandValues(t *testing.T) {
	initOnce = sync.Once{}
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "redis")

	sr := setupTestTracer(t)

	hook := newOtelRedisHook("localhost:6379")
	processHook := hook.ProcessHook(func(ctx context.Context, cmd redis.Cmder) error {
		return nil
	})

	cmd := redis.NewCmd(context.Background(), "set", "session:42", "s3cret-session-token")
	err := processHook(context.Background(), cmd)
	require.NoError(t, err)

	spans := sr.Ended()
	require.Len(t, spans, 1)

	queryText := ""
	for _, attr := range spans[0].Attributes() {
		if string(attr.Key) == "db.query.text" {
			queryText = attr.Value.AsString()
			break
		}
	}
	assert.Equal(t, "set session:42 ?", queryText)
	assert.NotContains(t, queryText, "s3cret-session-token", "the value must never reach db.query.text")
}

func TestRedisV9AppendArg(t *testing.T) {
	tests := []struct {
		name     string
		arg      interface{}
		expected string
	}{
		{"nil", nil, "<nil>"},
		{"string", "hello", "hello"},
		{"int", 42, "42"},
		{"int8", int8(8), "8"},
		{"int16", int16(16), "16"},
		{"int32", int32(32), "32"},
		{"int64", int64(64), "64"},
		{"uint", uint(42), "42"},
		{"uint8", uint8(8), "8"},
		{"uint16", uint16(16), "16"},
		{"uint32", uint32(32), "32"},
		{"uint64", uint64(64), "64"},
		{"float32", float32(3.14), "3.14"},
		{"float64", float64(3.14159), "3.14159"},
		{"bool true", true, "true"},
		{"bool false", false, "false"},
		{"bytes valid utf8", []byte("hello"), "hello"},
		{"unsupported type", struct{}{}, "not_support_type"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			b := redisV9AppendArg(nil, tt.arg)
			assert.Contains(t, string(b), tt.expected)
		})
	}
}

func TestRedisV9AppendArg_Time(t *testing.T) {
	now := time.Now()
	b := redisV9AppendArg(nil, now)
	result := string(b)
	// Should contain RFC3339Nano formatted time
	assert.NotEmpty(t, result)
	// Verify it can be parsed back
	_, err := time.Parse(time.RFC3339Nano, result)
	assert.NoError(t, err)
}

func TestRedisV9AppendArg_InvalidUTF8String(t *testing.T) {
	// Invalid UTF-8 byte sequence
	invalidStr := string([]byte{0xff, 0xfe, 0xfd})
	b := redisV9AppendArg(nil, invalidStr)
	result := string(b)
	assert.Equal(t, "<string>", result)
}

func TestRedisV9AppendArg_InvalidUTF8Bytes(t *testing.T) {
	// Invalid UTF-8 byte sequence
	invalidBytes := []byte{0xff, 0xfe, 0xfd}
	b := redisV9AppendArg(nil, invalidBytes)
	result := string(b)
	assert.Equal(t, "<byte>", result)
}

func TestRedisV9AppendArg_TruncatesLongArg(t *testing.T) {
	// Exactly at the limit: not truncated.
	atLimit := strings.Repeat("a", redisMaxArgBytes)
	got := string(redisV9AppendArg(nil, atLimit))
	assert.Equal(t, atLimit, got)

	// One byte over the limit: truncated with suffix.
	overLimit := strings.Repeat("a", redisMaxArgBytes+100)
	got = string(redisV9AppendArg(nil, overLimit))
	assert.Equal(t, atLimit+redisArgTruncatedSuffix, got)

	// []byte argument over the limit is also truncated.
	gotBytes := string(redisV9AppendArg(nil, []byte(overLimit)))
	assert.Equal(t, atLimit+redisArgTruncatedSuffix, gotBytes)
}

func TestRedisV9AppendArg_TruncatesPreservingUTF8(t *testing.T) {
	// Place a 3-byte rune ('€', 0xE2 0x82 0xAC) straddling the 256-byte boundary
	// (starting at index 255). Truncation must step back to index 255 so the
	// result remains valid UTF-8.
	prefix := strings.Repeat("a", redisMaxArgBytes-1)
	s := prefix + "€" + strings.Repeat("b", 50)
	got := string(redisV9AppendArg(nil, s))

	assert.True(t, utf8.ValidString(got), "truncated argument must be valid UTF-8")
	assert.Equal(t, prefix+redisArgTruncatedSuffix, got)
}

func TestGetRedisV9Statement_BoundsLargeKey(t *testing.T) {
	largeKey := strings.Repeat("k", 10*1024)
	cmd := redis.NewCmd(context.Background(), "get", largeKey)
	stmt := getRedisV9Statement(cmd)

	wantKey := strings.Repeat("k", redisMaxArgBytes) + redisArgTruncatedSuffix
	assert.Equal(t, "get "+wantKey, stmt)
}

func TestNewOtelRedisHook(t *testing.T) {
	hook := newOtelRedisHook("localhost:6379")
	assert.NotNil(t, hook)
	assert.Equal(t, "localhost:6379", hook.Addr)
}

func TestProcessHook_CreatesSpan(t *testing.T) {
	initOnce = *new(sync.Once)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "redis")

	sr := setupTestTracer(t)

	hook := newOtelRedisHook("localhost:6379")
	processHook := hook.ProcessHook(func(ctx context.Context, cmd redis.Cmder) error {
		return nil
	})

	cmd := redis.NewCmd(context.Background(), "get", "mykey")
	err := processHook(context.Background(), cmd)
	assert.NoError(t, err)

	spans := sr.Ended()
	require.Len(t, spans, 1)

	span := spans[0]
	assert.Equal(t, "get", span.Name())

	// Verify attributes
	attrMap := make(map[string]interface{})
	for _, attr := range span.Attributes() {
		attrMap[string(attr.Key)] = attr.Value.AsInterface()
	}
	assert.Equal(t, "redis", attrMap["db.system.name"])
	assert.Equal(t, "get", attrMap["db.operation.name"])
	assert.Equal(t, "localhost", attrMap["server.address"])
	assert.Equal(t, int64(6379), attrMap["server.port"])
}

func TestProcessHook_RedactsAuthCredentials(t *testing.T) {
	tests := []struct {
		name      string
		cmd       redis.Cmder
		spanName  string
		wantQuery string
	}{
		{
			name:      "AUTH",
			cmd:       redis.NewCmd(context.Background(), "auth", "s3cret"),
			spanName:  "auth",
			wantQuery: "auth ?",
		},
		{
			name:      "HELLO AUTH",
			cmd:       redis.NewCmd(context.Background(), "hello", 3, "auth", "default", "s3cret"),
			spanName:  "hello",
			wantQuery: "hello 3 auth ? ?",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			initOnce = *new(sync.Once)
			t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "redis")

			sr := setupTestTracer(t)
			hook := newOtelRedisHook("localhost:6379")
			processHook := hook.ProcessHook(func(ctx context.Context, cmd redis.Cmder) error {
				return nil
			})

			err := processHook(context.Background(), tt.cmd)
			assert.NoError(t, err)

			spans := sr.Ended()
			require.Len(t, spans, 1)
			assert.Equal(t, tt.spanName, spans[0].Name())

			queryText := ""
			for _, attr := range spans[0].Attributes() {
				if string(attr.Key) == "db.query.text" {
					queryText = attr.Value.AsString()
					break
				}
			}
			assert.Equal(t, tt.wantQuery, queryText)
			assert.NotContains(t, queryText, "s3cret")
		})
	}
}

func TestProcessHook_RecordsError(t *testing.T) {
	initOnce = *new(sync.Once)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "redis")

	sr := setupTestTracer(t)

	hook := newOtelRedisHook("localhost:6379")
	expectedErr := errors.New("connection refused")
	processHook := hook.ProcessHook(func(ctx context.Context, cmd redis.Cmder) error {
		return expectedErr
	})

	cmd := redis.NewCmd(context.Background(), "get", "mykey")
	err := processHook(context.Background(), cmd)
	assert.Equal(t, expectedErr, err)

	spans := sr.Ended()
	require.Len(t, spans, 1)

	span := spans[0]
	assert.Equal(t, codes.Error, span.Status().Code)
	assert.Contains(t, span.Status().Description, "connection refused")

	// Check that error was recorded
	events := span.Events()
	require.Len(t, events, 1)
	assert.Equal(t, "exception", events[0].Name)
}

func TestProcessHook_RedisNilNotError(t *testing.T) {
	initOnce = *new(sync.Once)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "redis")

	sr := setupTestTracer(t)

	hook := newOtelRedisHook("localhost:6379")
	processHook := hook.ProcessHook(func(ctx context.Context, cmd redis.Cmder) error {
		return redis.Nil
	})

	cmd := redis.NewCmd(context.Background(), "get", "nonexistent")
	err := processHook(context.Background(), cmd)
	// redis.Nil must be propagated so callers can detect cache misses via errors.Is
	assert.ErrorIs(t, err, redis.Nil)

	spans := sr.Ended()
	require.Len(t, spans, 1)

	span := spans[0]
	// redis.Nil should NOT mark the span as an error
	assert.Equal(t, codes.Unset, span.Status().Code)
}

func TestProcessHook_Disabled(t *testing.T) {
	initOnce = *new(sync.Once)
	t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "redis")

	sr := setupTestTracer(t)

	hook := newOtelRedisHook("localhost:6379")
	processHook := hook.ProcessHook(func(ctx context.Context, cmd redis.Cmder) error {
		return nil
	})

	cmd := redis.NewCmd(context.Background(), "get", "mykey")
	err := processHook(context.Background(), cmd)
	assert.NoError(t, err)

	spans := sr.Ended()
	assert.Len(t, spans, 0, "no spans should be created when instrumentation is disabled")
}

func TestProcessPipelineHook_CreatesSpan(t *testing.T) {
	initOnce = *new(sync.Once)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "redis")

	sr := setupTestTracer(t)

	hook := newOtelRedisHook("localhost:6379")
	pipelineHook := hook.ProcessPipelineHook(func(ctx context.Context, cmds []redis.Cmder) error {
		return nil
	})

	cmds := []redis.Cmder{
		redis.NewCmd(context.Background(), "get", "key1"),
		redis.NewCmd(context.Background(), "set", "key2", "val2"),
		redis.NewCmd(context.Background(), "del", "key3"),
	}
	err := pipelineHook(context.Background(), cmds)
	assert.NoError(t, err)

	spans := sr.Ended()
	require.Len(t, spans, 1)

	span := spans[0]
	assert.Equal(t, "pipeline", span.Name())

	// Verify attributes
	attrMap := make(map[string]interface{})
	for _, attr := range span.Attributes() {
		attrMap[string(attr.Key)] = attr.Value.AsInterface()
	}
	assert.Equal(t, "redis", attrMap["db.system.name"])
	assert.Equal(t, "pipeline", attrMap["db.operation.name"])
}

func TestProcessPipelineHook_TruncatesLongPipeline(t *testing.T) {
	initOnce = *new(sync.Once)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "redis")

	sr := setupTestTracer(t)

	hook := newOtelRedisHook("localhost:6379")
	pipelineHook := hook.ProcessPipelineHook(func(ctx context.Context, cmds []redis.Cmder) error {
		return nil
	})

	// Create more than 10 commands
	cmds := make([]redis.Cmder, 15)
	for i := range cmds {
		cmds[i] = redis.NewCmd(context.Background(), "get", "key")
	}
	err := pipelineHook(context.Background(), cmds)
	assert.NoError(t, err)

	spans := sr.Ended()
	require.Len(t, spans, 1)
}

func TestProcessPipelineHook_RecordsError(t *testing.T) {
	initOnce = *new(sync.Once)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "redis")

	sr := setupTestTracer(t)

	hook := newOtelRedisHook("localhost:6379")
	expectedErr := errors.New("pipeline error")
	pipelineHook := hook.ProcessPipelineHook(func(ctx context.Context, cmds []redis.Cmder) error {
		return expectedErr
	})

	cmds := []redis.Cmder{
		redis.NewCmd(context.Background(), "get", "key1"),
	}
	err := pipelineHook(context.Background(), cmds)
	assert.Equal(t, expectedErr, err)

	spans := sr.Ended()
	require.Len(t, spans, 1)

	span := spans[0]
	assert.Equal(t, codes.Error, span.Status().Code)

	// Check that error was recorded
	events := span.Events()
	require.Len(t, events, 1)
	assert.Equal(t, "exception", events[0].Name)
}

func TestProcessPipelineHook_Disabled(t *testing.T) {
	initOnce = *new(sync.Once)
	t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "redis")

	sr := setupTestTracer(t)

	hook := newOtelRedisHook("localhost:6379")
	pipelineHook := hook.ProcessPipelineHook(func(ctx context.Context, cmds []redis.Cmder) error {
		return nil
	})

	cmds := []redis.Cmder{
		redis.NewCmd(context.Background(), "get", "key1"),
	}
	err := pipelineHook(context.Background(), cmds)
	assert.NoError(t, err)

	spans := sr.Ended()
	assert.Len(t, spans, 0)
}

func TestDialHook_Success(t *testing.T) {
	hook := newOtelRedisHook("localhost:6379")

	// Create a mock connection using net.Pipe
	serverConn, clientConn := net.Pipe()
	defer serverConn.Close()
	defer clientConn.Close()

	dialHook := hook.DialHook(func(ctx context.Context, network, addr string) (net.Conn, error) {
		return clientConn, nil
	})

	conn, err := dialHook(context.Background(), "tcp", "localhost:6379")
	assert.NoError(t, err)
	assert.NotNil(t, conn)
}

func TestDialHook_Error(t *testing.T) {
	hook := newOtelRedisHook("localhost:6379")
	expectedErr := errors.New("dial tcp: connection refused")

	dialHook := hook.DialHook(func(ctx context.Context, network, addr string) (net.Conn, error) {
		return nil, expectedErr
	})

	conn, err := dialHook(context.Background(), "tcp", "localhost:6379")
	assert.Equal(t, expectedErr, err)
	assert.Nil(t, conn)
}

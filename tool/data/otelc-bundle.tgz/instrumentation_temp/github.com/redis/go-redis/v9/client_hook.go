// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package v9

import (
	redis "github.com/redis/go-redis/v9"

	"go.opentelemetry.io/otelc/pkg/hook"
	"go.opentelemetry.io/otelc/pkg/runtime"
)

const (
	instrumentationName = "go.opentelemetry.io/otelc/instrumentation/github.com/redis/go-redis/v9"
	instrumentationKey  = "REDIS"
)

// redisClientEnabler controls whether client instrumentation is enabled
type redisClientEnabler struct{}

func (g redisClientEnabler) Enable() bool {
	return runtime.Instrumented(instrumentationKey)
}

var redisEnabler = redisClientEnabler{}

// Ring and ClusterClient use redis.NewClient by default to create their node
// clients (unless overridden via RingOptions.NewClient or ClusterOptions.NewClient),
// so this hook instruments them too.
func afterNewRedisClientV9(ictx hook.HookContext, client *redis.Client) {
	client.AddHook(newOtelRedisHook(client.Options().Addr))
}

func afterNewFailOverRedisClientV9(call hook.HookContext, client *redis.Client) {
	client.AddHook(newOtelRedisHook(client.Options().Addr))
}

func afterNewSentinelClientV9(call hook.HookContext, client *redis.SentinelClient) {
	client.AddHook(newOtelRedisHook(client.String()))
}

func afterClientConnV9(call hook.HookContext, client *redis.Conn) {
	client.AddHook(newOtelRedisHook(client.String()))
}

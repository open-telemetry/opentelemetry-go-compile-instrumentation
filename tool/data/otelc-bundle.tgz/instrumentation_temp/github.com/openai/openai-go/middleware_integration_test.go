// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package v1

import (
	"bytes"
	"context"
	"errors"
	"io"
	"log/slog"
	"net/http"
	"strconv"
	"strings"
	"testing"

	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/otel"
	otelcodes "go.opentelemetry.io/otel/codes"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"go.opentelemetry.io/otel/sdk/trace/tracetest"
)

func setupTestTracer(t *testing.T) *tracetest.SpanRecorder {
	t.Helper()
	sr := tracetest.NewSpanRecorder()
	tp := sdktrace.NewTracerProvider(sdktrace.WithSpanProcessor(sr))
	otel.SetTracerProvider(tp)
	tracer = tp.Tracer("test")
	t.Cleanup(func() { _ = tp.Shutdown(context.Background()) })
	return sr
}

type partialReadErrorReader struct {
	prefix []byte
	err    error
	read   bool
}

func (r *partialReadErrorReader) Read(p []byte) (int, error) {
	if !r.read {
		r.read = true
		return copy(p, r.prefix), nil
	}
	return 0, r.err
}

func TestOtelMiddleware_ChatCompletion(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	reqBody := `{"model":"gpt-4","max_tokens":100,"temperature":0.7,"top_p":0.9,"frequency_penalty":0.5,"presence_penalty":0.3}`
	req, _ := http.NewRequest(
		"POST",
		"https://api.openai.com/v1/chat/completions",
		io.NopCloser(bytes.NewReader([]byte(reqBody))),
	)

	respBody := `{"id":"chatcmpl-123","model":"gpt-4","choices":[{"finish_reason":"stop"}],"usage":{"prompt_tokens":10,"completion_tokens":20,"total_tokens":30}}`
	next := func(r *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: 200,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(bytes.NewReader([]byte(respBody))),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)

	spans := sr.Ended()
	require.Len(t, spans, 1)

	span := spans[0]
	assert.Equal(t, "chat gpt-4", span.Name())

	attrs := span.Attributes()
	assertAttribute(t, attrs, "gen_ai.system", "openai")
	assertAttribute(t, attrs, "gen_ai.operation.name", "chat")
	assertAttribute(t, attrs, "gen_ai.request.model", "gpt-4")
	assertAttribute(t, attrs, "gen_ai.provider.name", "openai")
	assertAttribute(t, attrs, "server.address", "api.openai.com")
	assertInt64Attribute(t, attrs, "server.port", 443)
	assertAttribute(t, attrs, "gen_ai.response.id", "chatcmpl-123")
	assertAttribute(t, attrs, "gen_ai.response.model", "gpt-4")
	assertInt64Attribute(t, attrs, "gen_ai.usage.input_tokens", 10)
	assertInt64Attribute(t, attrs, "gen_ai.usage.output_tokens", 20)
	assertInt64Attribute(t, attrs, "gen_ai.usage.total_tokens", 30)
	assertInt64Attribute(t, attrs, "gen_ai.request.max_tokens", 100)
	assertFloat64Attribute(t, attrs, "gen_ai.request.temperature", 0.7)
	assertFloat64Attribute(t, attrs, "gen_ai.request.top_p", 0.9)
	assertFloat64Attribute(t, attrs, "gen_ai.request.frequency_penalty", 0.5)
	assertFloat64Attribute(t, attrs, "gen_ai.request.presence_penalty", 0.3)
}

func TestOtelMiddleware_ChatCompletion_MaxCompletionTokens(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	reqBody := `{"model":"gpt-4.1","max_completion_tokens":200}`
	req, _ := http.NewRequest(
		"POST",
		"http://api.openai.com/v1/chat/completions",
		io.NopCloser(bytes.NewReader([]byte(reqBody))),
	)

	respBody := `{"id":"chatcmpl-123","model":"gpt-4.1","choices":[{"finish_reason":"stop"}],"usage":{"prompt_tokens":10,"completion_tokens":20,"total_tokens":30}}`
	next := func(r *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: 200,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(bytes.NewReader([]byte(respBody))),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)

	spans := sr.Ended()
	require.Len(t, spans, 1)
	assertInt64Attribute(t, spans[0].Attributes(), "gen_ai.request.max_tokens", 200)
}

func TestOtelMiddleware_Completion(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	reqBody := `{"model":"gpt-3.5-turbo-instruct","max_tokens":50,"temperature":0.5}`
	req, _ := http.NewRequest(
		"POST",
		"http://api.openai.com/v1/completions",
		io.NopCloser(bytes.NewReader([]byte(reqBody))),
	)

	respBody := `{"id":"cmpl-456","model":"gpt-3.5-turbo-instruct","choices":[{"finish_reason":"length"}],"usage":{"prompt_tokens":5,"completion_tokens":50,"total_tokens":55}}`
	next := func(r *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: 200,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(bytes.NewReader([]byte(respBody))),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)

	spans := sr.Ended()
	require.Len(t, spans, 1)

	span := spans[0]
	assert.Equal(t, "text_completion gpt-3.5-turbo-instruct", span.Name())

	attrs := span.Attributes()
	assertAttribute(t, attrs, "gen_ai.system", "openai")
	assertAttribute(t, attrs, "gen_ai.operation.name", "text_completion")
	assertAttribute(t, attrs, "gen_ai.request.model", "gpt-3.5-turbo-instruct")
	assertAttribute(t, attrs, "gen_ai.response.id", "cmpl-456")
	assertInt64Attribute(t, attrs, "gen_ai.usage.input_tokens", 5)
	assertInt64Attribute(t, attrs, "gen_ai.usage.output_tokens", 50)
}

func TestOtelMiddleware_Embedding(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	reqBody := `{"model":"text-embedding-ada-002","input":"hello world"}`
	req, _ := http.NewRequest(
		"POST",
		"http://api.openai.com/v1/embeddings",
		io.NopCloser(bytes.NewReader([]byte(reqBody))),
	)

	respBody := `{"model":"text-embedding-ada-002","usage":{"prompt_tokens":2,"total_tokens":2}}`
	next := func(r *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: 200,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(bytes.NewReader([]byte(respBody))),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)

	spans := sr.Ended()
	require.Len(t, spans, 1)

	span := spans[0]
	assert.Equal(t, "embeddings text-embedding-ada-002", span.Name())

	attrs := span.Attributes()
	assertAttribute(t, attrs, "gen_ai.system", "openai")
	assertAttribute(t, attrs, "gen_ai.operation.name", "embeddings")
	assertAttribute(t, attrs, "gen_ai.request.model", "text-embedding-ada-002")
	assertAttribute(t, attrs, "gen_ai.response.model", "text-embedding-ada-002")
	assertInt64Attribute(t, attrs, "gen_ai.usage.input_tokens", 2)
	assertInt64Attribute(t, attrs, "gen_ai.usage.total_tokens", 2)
}

func TestOtelMiddleware_UnknownOperation(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	reqBody := `{"model":"gpt-4"}`
	req, _ := http.NewRequest("POST", "http://api.openai.com/v1/models", io.NopCloser(bytes.NewReader([]byte(reqBody))))

	next := func(r *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: 200,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(bytes.NewReader([]byte(`{}`))),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)

	spans := sr.Ended()
	assert.Len(t, spans, 0, "unknown operations should not create spans")
}

func TestOtelMiddleware_NilBody(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	req, _ := http.NewRequest("GET", "http://api.openai.com/v1/chat/completions", nil)

	next := func(r *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: 200,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(bytes.NewReader([]byte(`{}`))),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)

	spans := sr.Ended()
	assert.Len(t, spans, 0, "nil body should skip instrumentation")
}

func TestOtelMiddleware_InvalidRequestJSON(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	req, _ := http.NewRequest(
		http.MethodPost,
		"http://api.openai.com/v1/chat/completions",
		io.NopCloser(bytes.NewReader([]byte("not json"))),
	)

	next := func(r *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: http.StatusOK,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(bytes.NewReader([]byte(`{}`))),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)

	spans := sr.Ended()
	assert.Empty(t, spans, "unparsable request body should skip instrumentation")
}

func TestOtelMiddleware_MissingModel(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	req, _ := http.NewRequest(
		http.MethodPost,
		"http://api.openai.com/v1/chat/completions",
		io.NopCloser(bytes.NewReader([]byte(`{"max_tokens":10}`))),
	)

	next := func(r *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: http.StatusOK,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(bytes.NewReader([]byte(`{}`))),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)

	spans := sr.Ended()
	assert.Empty(t, spans, "valid JSON missing the model field should skip instrumentation")
}

func TestOtelMiddleware_NextError(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	reqBody := `{"model":"gpt-4"}`
	req, _ := http.NewRequest(
		"POST",
		"http://api.openai.com/v1/chat/completions",
		io.NopCloser(bytes.NewReader([]byte(reqBody))),
	)

	next := func(r *http.Request) (*http.Response, error) {
		return nil, assert.AnError
	}

	resp, err := middleware(req, next)
	assert.Error(t, err)
	assert.Nil(t, resp)

	spans := sr.Ended()
	require.Len(t, spans, 1)

	span := spans[0]
	assert.Equal(t, "chat gpt-4", span.Name())

	events := span.Events()
	require.Len(t, events, 1, "expected exception event for transport error")
	assert.Equal(t, "exception", events[0].Name)

	assertAttribute(t, span.Attributes(), "error.type", "*errors.errorString")
}

func TestOtelMiddleware_HTTPErrorStatus(t *testing.T) {
	tests := []struct {
		name        string
		statusCode  int
		status      string
		contentType string
	}{
		{"rate limit", 429, "429 Too Many Requests", "application/json"},
		{"server error", 500, "500 Internal Server Error", "application/json"},
		{"streaming error", 500, "500 Internal Server Error", "text/event-stream"},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			sr := setupTestTracer(t)
			middleware := OtelMiddleware()

			reqBody := `{"model":"gpt-4"}`
			req, _ := http.NewRequest(
				"POST",
				"http://api.openai.com/v1/chat/completions",
				io.NopCloser(bytes.NewReader([]byte(reqBody))),
			)

			next := func(r *http.Request) (*http.Response, error) {
				return &http.Response{
					StatusCode: tt.statusCode,
					Status:     tt.status,
					Header:     http.Header{"Content-Type": []string{tt.contentType}},
					Body:       io.NopCloser(bytes.NewReader(nil)),
				}, nil
			}

			resp, err := middleware(req, next)
			require.NoError(t, err)
			require.NotNil(t, resp)

			spans := sr.Ended()
			require.Len(t, spans, 1)

			span := spans[0]
			assert.Equal(t, otelcodes.Error, span.Status().Code)

			events := span.Events()
			require.Len(t, events, 1, "expected exception event for HTTP error status")
			assert.Equal(t, "exception", events[0].Name)

			assertAttribute(t, span.Attributes(), "error.type", strconv.Itoa(tt.statusCode))
		})
	}
}

func TestOtelMiddleware_RequestBodyReadError(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	wantErr := errors.New("read fail")
	req, _ := http.NewRequest(
		"POST",
		"http://api.openai.com/v1/chat/completions",
		io.NopCloser(&partialReadErrorReader{prefix: []byte(`{"model":"gpt-4"}`), err: wantErr}),
	)

	called := false
	next := func(r *http.Request) (*http.Response, error) {
		called = true
		body, err := io.ReadAll(r.Body)
		require.ErrorIs(t, err, wantErr)
		assert.Equal(t, `{"model":"gpt-4"}`, string(body))
		return &http.Response{
			StatusCode: 200,
			Header:     http.Header{},
			Body:       io.NopCloser(bytes.NewReader(nil)),
		}, nil
	}

	_, err := middleware(req, next)
	require.NoError(t, err)
	assert.True(t, called)
	assert.Empty(t, sr.Ended())
}

func TestOtelMiddleware_ResponseBodyReadError(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	reqBody := `{"model":"gpt-4"}`
	req, _ := http.NewRequest(
		"POST",
		"http://api.openai.com/v1/chat/completions",
		io.NopCloser(bytes.NewReader([]byte(reqBody))),
	)

	wantErr := errors.New("response read fail")
	next := func(r *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: 200,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(&partialReadErrorReader{prefix: []byte(`{"id":"chatcmpl-123"}`), err: wantErr}),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)

	body, err := io.ReadAll(resp.Body)
	require.ErrorIs(t, err, wantErr)
	assert.Equal(t, `{"id":"chatcmpl-123"}`, string(body))

	spans := sr.Ended()
	require.Len(t, spans, 1)
}

func TestOtelMiddleware_ProviderDetection(t *testing.T) {
	tests := []struct {
		name            string
		host            string
		expected        string
		expectedAddress string
		expectedPort    int64
	}{
		{"deepseek", "api.deepseek.com", "deepseek", "api.deepseek.com", 443},
		{"azure", "myendpoint.azure.com", "azure", "myendpoint.azure.com", 443},
		{"local", "localhost:11434", "local", "localhost", 11434},
		{"groq", "api.groq.com", "groq", "api.groq.com", 443},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			sr := setupTestTracer(t)
			middleware := OtelMiddleware()

			reqBody := `{"model":"test-model"}`
			req, _ := http.NewRequest(
				"POST",
				"https://"+tt.host+"/v1/chat/completions",
				io.NopCloser(bytes.NewReader([]byte(reqBody))),
			)

			respBody := `{"id":"test","model":"test-model","choices":[],"usage":{"prompt_tokens":1,"completion_tokens":1,"total_tokens":2}}`
			next := func(r *http.Request) (*http.Response, error) {
				return &http.Response{
					StatusCode: 200,
					Header:     http.Header{"Content-Type": []string{"application/json"}},
					Body:       io.NopCloser(bytes.NewReader([]byte(respBody))),
				}, nil
			}

			_, err := middleware(req, next)
			require.NoError(t, err)

			spans := sr.Ended()
			require.Len(t, spans, 1)
			attrs := spans[0].Attributes()
			assertAttribute(t, attrs, "gen_ai.provider.name", tt.expected)
			assertAttribute(t, attrs, "server.address", tt.expectedAddress)
			assertInt64Attribute(t, attrs, "server.port", tt.expectedPort)
		})
	}
}

func TestOtelMiddleware_StreamingResponse(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	reqBody := `{"model":"gpt-4","stream":true}`
	req, _ := http.NewRequest(
		"POST",
		"http://api.openai.com/v1/chat/completions",
		io.NopCloser(bytes.NewReader([]byte(reqBody))),
	)

	streamData := "data: {\"id\":\"chatcmpl-stream\",\"model\":\"gpt-4\",\"choices\":[{\"delta\":{\"content\":\"Hello\"},\"finish_reason\":null}]}\n\ndata: {\"id\":\"chatcmpl-stream\",\"model\":\"gpt-4\",\"choices\":[{\"delta\":{\"content\":\" world\"},\"finish_reason\":\"stop\"}],\"usage\":{\"prompt_tokens\":5,\"completion_tokens\":2,\"total_tokens\":7}}\n\ndata: [DONE]\n\n"
	next := func(r *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: 200,
			Header:     http.Header{"Content-Type": []string{"text/event-stream"}},
			Body:       io.NopCloser(bytes.NewReader([]byte(streamData))),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)

	// Read the streaming body to completion to trigger finalization
	body, err := io.ReadAll(resp.Body)
	require.NoError(t, err)
	assert.Contains(t, string(body), "Hello")
	resp.Body.Close()

	spans := sr.Ended()
	require.Len(t, spans, 1)

	span := spans[0]
	assert.Equal(t, "chat gpt-4", span.Name())

	attrs := span.Attributes()
	assertAttribute(t, attrs, "gen_ai.system", "openai")
	assertAttribute(t, attrs, "gen_ai.request.is_stream", "true")
	assertAttribute(t, attrs, "gen_ai.response.id", "chatcmpl-stream")
	assertAttribute(t, attrs, "gen_ai.response.model", "gpt-4")
	assertInt64Attribute(t, attrs, "gen_ai.usage.input_tokens", 5)
	assertInt64Attribute(t, attrs, "gen_ai.usage.output_tokens", 2)
	assertInt64Attribute(t, attrs, "gen_ai.usage.total_tokens", 7)
}

// TestOtelMiddleware_ResponseBodyTruncated covers Issue #1309: a response
// larger than maxResponseBodySize (e.g. a large batch embeddings call) must
// not produce a span that silently looks fully successful. The span should
// still carry request-side attributes, the caller must still see the
// complete, untruncated body, and the drop should be logged rather than
// silent.
func TestOtelMiddleware_ResponseBodyTruncated(t *testing.T) {
	sr := setupTestTracer(t)

	var logBuf bytes.Buffer
	origLogger := logger
	t.Cleanup(func() { logger = origLogger })
	logger = slog.New(slog.NewJSONHandler(&logBuf, &slog.HandlerOptions{Level: slog.LevelDebug}))

	middleware := OtelMiddleware()

	reqBody := `{"model":"gpt-4"}`
	req, _ := http.NewRequest(
		"POST",
		"http://api.openai.com/v1/chat/completions",
		io.NopCloser(bytes.NewReader([]byte(reqBody))),
	)

	// A response whose JSON would otherwise be valid, but padded past
	// maxResponseBodySize the way a large batch response would be.
	padding := strings.Repeat("x", maxResponseBodySize)
	oversized := `{"id":"chatcmpl-big","model":"gpt-4","choices":[{"finish_reason":"stop"}],` +
		`"usage":{"prompt_tokens":1,"completion_tokens":1,"total_tokens":2},"padding":"` + padding + `"}`
	next := func(r *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: 200,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(strings.NewReader(oversized)),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)

	// The full, untruncated body must still reach the caller - only the
	// telemetry parse is bounded, not what the SDK receives.
	body, err := io.ReadAll(resp.Body)
	require.NoError(t, err)
	assert.Equal(t, oversized, string(body))

	spans := sr.Ended()
	require.Len(t, spans, 1)

	attrs := spans[0].Attributes()
	assertAttribute(t, attrs, "gen_ai.request.model", "gpt-4")
	assertNoAttribute(t, attrs, "gen_ai.response.model")
	assertNoAttribute(t, attrs, "gen_ai.response.id")
	assertNoAttribute(t, attrs, "gen_ai.usage.total_tokens")

	assert.Contains(t, logBuf.String(), "response body exceeded size cap",
		"a truncated response must be logged instead of silently dropped")
}

// TestOtelMiddleware_RequestBodyTruncated covers Issue #1314: a request
// larger than maxRequestBodySize must not silently vanish from telemetry
// without at least a log line, and the SDK must still receive the complete
// body.
func TestOtelMiddleware_RequestBodyTruncated(t *testing.T) {
	sr := setupTestTracer(t)

	var logBuf bytes.Buffer
	origLogger := logger
	t.Cleanup(func() { logger = origLogger })
	logger = slog.New(slog.NewJSONHandler(&logBuf, &slog.HandlerOptions{Level: slog.LevelDebug}))

	middleware := OtelMiddleware()

	padding := strings.Repeat("x", maxRequestBodySize)
	oversized := `{"model":"gpt-4","padding":"` + padding + `"}`
	req, _ := http.NewRequest(
		"POST",
		"http://api.openai.com/v1/chat/completions",
		io.NopCloser(strings.NewReader(oversized)),
	)

	called := false
	next := func(r *http.Request) (*http.Response, error) {
		called = true
		body, err := io.ReadAll(r.Body)
		require.NoError(t, err)
		assert.Equal(t, oversized, string(body), "the SDK must still see the full, untruncated request body")
		return &http.Response{
			StatusCode: 200,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body: io.NopCloser(bytes.NewReader([]byte(
				`{"id":"chatcmpl-1","model":"gpt-4","choices":[],"usage":{"prompt_tokens":7,"completion_tokens":3,"total_tokens":10}}`,
			))),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)
	assert.True(t, called)

	spans := sr.Ended()
	require.Len(t, spans, 1, "an oversized request must still produce a span for its response telemetry")
	attrs := spans[0].Attributes()
	assertAttribute(t, attrs, "gen_ai.operation.name", "chat")
	assertNoAttribute(t, attrs, "gen_ai.request.model")
	assertAttribute(t, attrs, "gen_ai.response.model", "gpt-4")
	assertInt64Attribute(t, attrs, "gen_ai.usage.input_tokens", 7)
	assert.Contains(t, logBuf.String(), "request body exceeded size cap",
		"a truncated request must be logged instead of silently dropped")
}

func TestOtelMiddleware_AzurePath(t *testing.T) {
	sr := setupTestTracer(t)

	middleware := OtelMiddleware()

	reqBody := `{"model":"gpt-4"}`
	req, _ := http.NewRequest(
		"POST",
		"http://myendpoint.azure.com/openai/deployments/gpt-4/chat/completions",
		io.NopCloser(bytes.NewReader([]byte(reqBody))),
	)

	respBody := `{"id":"azure-123","model":"gpt-4","choices":[{"finish_reason":"stop"}],"usage":{"prompt_tokens":3,"completion_tokens":5,"total_tokens":8}}`
	next := func(r *http.Request) (*http.Response, error) {
		return &http.Response{
			StatusCode: 200,
			Header:     http.Header{"Content-Type": []string{"application/json"}},
			Body:       io.NopCloser(bytes.NewReader([]byte(respBody))),
		}, nil
	}

	resp, err := middleware(req, next)
	require.NoError(t, err)
	require.NotNil(t, resp)

	spans := sr.Ended()
	require.Len(t, spans, 1)

	attrs := spans[0].Attributes()
	assertAttribute(t, attrs, "gen_ai.operation.name", "chat")
	assertAttribute(t, attrs, "gen_ai.provider.name", "azure")
}

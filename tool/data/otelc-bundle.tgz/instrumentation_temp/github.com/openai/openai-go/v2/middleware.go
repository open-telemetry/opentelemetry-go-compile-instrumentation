// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package v2

import (
	"bytes"
	"context"
	"encoding/json"
	"errors"
	"io"
	"net/http"
	"strconv"
	"strings"
	"time"

	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	"go.opentelemetry.io/otel/metric"
	otelsemconv "go.opentelemetry.io/otel/semconv/v1.37.0"
	"go.opentelemetry.io/otel/trace"

	"go.opentelemetry.io/otelc/instrumentation/github.com/openai/openai-go/v2/semconv"
	"go.opentelemetry.io/otelc/pkg/runtime"
)

const (
	maxRequestBodySize  = 1 << 20 // 1 MB
	maxResponseBodySize = 4 << 20 // 4 MB
)

// providerMapping is checked in order: the first entry whose keyword is a
// substring of the request host wins. It is a slice, not a map, because Go
// map iteration order is randomized on every range - a map here would make
// getProviderName non-deterministic whenever a host matched more than one
// keyword (see Issue #824).
var providerMapping = []struct { //nolint:gochecknoglobals // private lookup table
	keyword  string
	provider string
}{
	{"openai.com", "openai"},
	{"azure.com", "azure"},
	{"anthropic.com", "anthropic"},
	{"dashscope.aliyuncs", "qwen"},
	{"volces.com", "ark"},
	{"ark.cn", "ark"},
	{"hunyuan", "tencent"},
	{"tencentcloudapi", "tencent"},
	{"googleapis.com", "google"},
	{"generativelanguage", "google"},
	{"deepseek.com", "deepseek"},
	{"moonshot", "moonshot"},
	{"zhipuai.cn", "zhipu"},
	{"bigmodel.cn", "zhipu"},
	{"baidu.com", "baidu"},
	{"minimax", "minimax"},
	{"siliconflow", "siliconflow"},
	{"together", "together"},
	{"mistral", "mistral"},
	{"groq.com", "groq"},
	{"ollama", "ollama"},
	{"localhost", "local"},
	{"127.0.0.1", "local"},
}

func getProviderName(host string) string {
	for _, entry := range providerMapping {
		if strings.Contains(host, entry.keyword) {
			return entry.provider
		}
	}
	return "openai"
}

type operationType int

const (
	opChat operationType = iota
	opCompletion
	opEmbedding
	opUnknown
)

func classifyOperation(path string) operationType {
	if strings.HasSuffix(path, "chat/completions") {
		return opChat
	}
	if strings.HasSuffix(path, "completions") {
		return opCompletion
	}
	if strings.HasSuffix(path, "embeddings") {
		return opEmbedding
	}
	return opUnknown
}

func operationName(op operationType) string {
	switch op {
	case opChat:
		return "chat"
	case opCompletion:
		return "text_completion"
	case opEmbedding:
		return "embeddings"
	default:
		return ""
	}
}

// OtelMiddleware returns an HTTP middleware that creates spans for OpenAI API
// calls following GenAI semantic conventions.
func OtelMiddleware() func(*http.Request, func(*http.Request) (*http.Response, error)) (*http.Response, error) {
	return func(req *http.Request, next func(*http.Request) (*http.Response, error)) (*http.Response, error) {
		if req.Body == nil {
			return next(req)
		}

		op := classifyOperation(req.URL.Path)
		if op == opUnknown {
			return next(req)
		}

		start := time.Now()
		provider := getProviderName(req.URL.Host)
		opName := operationName(op)

		// Read a bounded copy for attribute parsing, but preserve the full body for the SDK.
		var buf bytes.Buffer
		tee := io.TeeReader(req.Body, &buf)
		bodyBytes, err := io.ReadAll(io.LimitReader(tee, maxRequestBodySize))
		// Reassemble: buffered bytes + remaining unread body.
		req.Body = struct {
			io.Reader
			io.Closer
		}{io.MultiReader(&buf, req.Body), req.Body}
		if err != nil {
			return next(req)
		}

		var model string
		var spanAttrs []attribute.KeyValue

		switch op {
		case opChat:
			model, spanAttrs = parseChatRequest(bodyBytes)
		case opCompletion:
			model, spanAttrs = parseCompletionRequest(bodyBytes)
		case opEmbedding:
			model, spanAttrs = parseEmbeddingRequest(bodyBytes)
		}

		if model == "" {
			return next(req)
		}

		spanName := opName + " " + model
		baseAttrs := []attribute.KeyValue{
			semconv.GenAISystem("openai"),
			semconv.GenAIOperationName(opName),
			semconv.GenAIRequestModel(model),
			semconv.GenAIProviderName(provider),
		}
		spanAttrs = append(baseAttrs, spanAttrs...)

		ctx := req.Context()
		ctx, span := tracer.Start(ctx, spanName,
			trace.WithSpanKind(trace.SpanKindClient),
			trace.WithAttributes(spanAttrs...),
		)
		ctx = runtime.SuppressHTTPClientInstrumentation(ctx)
		req = req.WithContext(ctx)

		resp, err := next(req)
		if err != nil {
			span.SetStatus(codes.Error, err.Error())
			span.RecordError(err)
			span.SetAttributes(otelsemconv.ErrorType(err))
			span.End()
			return resp, err
		}

		if resp.StatusCode >= 400 {
			span.RecordError(errors.New(resp.Status))
			span.SetStatus(codes.Error, resp.Status)
			span.SetAttributes(otelsemconv.ErrorTypeKey.String(strconv.Itoa(resp.StatusCode)))
			span.End()
			return resp, nil
		}

		contentType := resp.Header.Get("Content-Type")
		isStreaming := strings.HasPrefix(contentType, "text/event-stream")

		if isStreaming {
			span.SetAttributes(semconv.GenAIRequestIsStream(true))
			resp.Body = newStreamingReader(resp.Body, span, start, op)
		} else {
			handleNonStreamingResponse(ctx, resp, span, op, baseAttrs)
		}

		return resp, nil
	}
}

func handleNonStreamingResponse(
	ctx context.Context,
	resp *http.Response,
	span trace.Span,
	op operationType,
	baseAttrs []attribute.KeyValue,
) {
	defer span.End()

	// Read a bounded preview for parsing, but reassemble the full body for callers.
	var buf bytes.Buffer
	tee := io.TeeReader(resp.Body, &buf)
	bodyBytes, err := io.ReadAll(io.LimitReader(tee, maxResponseBodySize))
	// Reassemble: preview bytes + remaining unread body.
	resp.Body = struct {
		io.Reader
		io.Closer
	}{io.MultiReader(&buf, resp.Body), resp.Body}
	if err != nil {
		return
	}

	var inputTokens, outputTokens *int64
	switch op {
	case opChat:
		inputTokens, outputTokens = parseChatResponse(bodyBytes, span)
	case opCompletion:
		inputTokens, outputTokens = parseCompletionResponse(bodyBytes, span)
	case opEmbedding:
		inputTokens, outputTokens = parseEmbeddingResponse(bodyBytes, span)
	}
	recordTokenUsage(ctx, baseAttrs, inputTokens, outputTokens)
}

// recordTokenUsage emits the gen_ai.client.token.usage histogram, once per
// token type the response actually reported.
//
// A nil count means the provider reported nothing for that token type: either
// the response carried no usage object, or the field does not exist for the
// operation (embeddings have no completion_tokens). A reported zero is recorded
// as a zero, so the data point count stays usable as "how many operations
// reported usage" rather than collapsing absent and zero into the same result.
//
// The base attributes are copied so the gen_ai.token.type tag never mutates the
// caller's slice.
func recordTokenUsage(ctx context.Context, baseAttrs []attribute.KeyValue, inputTokens, outputTokens *int64) {
	if tokenUsage == nil {
		return
	}
	record := func(tokens int64, tokenType string) {
		attrs := make([]attribute.KeyValue, 0, len(baseAttrs)+1)
		attrs = append(attrs, baseAttrs...)
		attrs = append(attrs, semconv.GenAITokenType(tokenType))
		tokenUsage.Record(ctx, tokens, metric.WithAttributes(attrs...))
	}
	if inputTokens != nil {
		record(*inputTokens, "input")
	}
	if outputTokens != nil {
		record(*outputTokens, "output")
	}
}

func parseChatRequest(body []byte) (string, []attribute.KeyValue) {
	var req struct {
		Model            string   `json:"model"`
		MaxTokens        *int64   `json:"max_tokens,omitempty"`
		Temperature      *float64 `json:"temperature,omitempty"`
		TopP             *float64 `json:"top_p,omitempty"`
		FrequencyPenalty *float64 `json:"frequency_penalty,omitempty"`
		PresencePenalty  *float64 `json:"presence_penalty,omitempty"`
	}
	if err := json.Unmarshal(body, &req); err != nil {
		return "", nil
	}

	var attrs []attribute.KeyValue
	if req.MaxTokens != nil {
		attrs = append(attrs, semconv.GenAIRequestMaxTokens(*req.MaxTokens))
	}
	if req.Temperature != nil {
		attrs = append(attrs, semconv.GenAIRequestTemperature(*req.Temperature))
	}
	if req.TopP != nil {
		attrs = append(attrs, semconv.GenAIRequestTopP(*req.TopP))
	}
	if req.FrequencyPenalty != nil {
		attrs = append(attrs, semconv.GenAIRequestFrequencyPenalty(*req.FrequencyPenalty))
	}
	if req.PresencePenalty != nil {
		attrs = append(attrs, semconv.GenAIRequestPresencePenalty(*req.PresencePenalty))
	}
	return req.Model, attrs
}

func parseCompletionRequest(body []byte) (string, []attribute.KeyValue) {
	var req struct {
		Model       string   `json:"model"`
		MaxTokens   *int64   `json:"max_tokens,omitempty"`
		Temperature *float64 `json:"temperature,omitempty"`
		TopP        *float64 `json:"top_p,omitempty"`
	}
	if err := json.Unmarshal(body, &req); err != nil {
		return "", nil
	}

	var attrs []attribute.KeyValue
	if req.MaxTokens != nil {
		attrs = append(attrs, semconv.GenAIRequestMaxTokens(*req.MaxTokens))
	}
	if req.Temperature != nil {
		attrs = append(attrs, semconv.GenAIRequestTemperature(*req.Temperature))
	}
	if req.TopP != nil {
		attrs = append(attrs, semconv.GenAIRequestTopP(*req.TopP))
	}
	return req.Model, attrs
}

func parseEmbeddingRequest(body []byte) (string, []attribute.KeyValue) {
	var req struct {
		Model string `json:"model"`
	}
	if err := json.Unmarshal(body, &req); err != nil {
		return "", nil
	}
	return req.Model, nil
}

// parseChatResponse sets response attributes on the span and returns the
// input and output token counts for metric recording.
func parseChatResponse(body []byte, span trace.Span) (*int64, *int64) {
	var resp struct {
		ID      string `json:"id"`
		Model   string `json:"model"`
		Choices []struct {
			FinishReason string `json:"finish_reason"`
		} `json:"choices"`
		// Pointer so an absent usage object is distinguishable from one
		// reporting genuine zeros; the metric records the latter but not the
		// former.
		Usage *struct {
			PromptTokens     int64 `json:"prompt_tokens"`
			CompletionTokens int64 `json:"completion_tokens"`
			TotalTokens      int64 `json:"total_tokens"`
		} `json:"usage"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil, nil
	}

	var reasons []string
	for _, c := range resp.Choices {
		if c.FinishReason != "" {
			reasons = append(reasons, c.FinishReason)
		}
	}

	var input, output, total int64
	if resp.Usage != nil {
		input, output, total = resp.Usage.PromptTokens, resp.Usage.CompletionTokens, resp.Usage.TotalTokens
	}
	span.SetAttributes(
		semconv.GenAIResponseID(resp.ID),
		semconv.GenAIResponseModel(resp.Model),
		semconv.GenAIResponseFinishReasons(reasons),
		semconv.GenAIUsageInputTokens(input),
		semconv.GenAIUsageOutputTokens(output),
		semconv.GenAIUsageTotalTokens(total),
	)
	if resp.Usage == nil {
		return nil, nil
	}
	return &input, &output
}

// parseCompletionResponse sets response attributes on the span and returns the
// input and output token counts for metric recording.
func parseCompletionResponse(body []byte, span trace.Span) (*int64, *int64) {
	var resp struct {
		ID      string `json:"id"`
		Model   string `json:"model"`
		Choices []struct {
			FinishReason string `json:"finish_reason"`
		} `json:"choices"`
		// Pointer so an absent usage object is distinguishable from one
		// reporting genuine zeros; the metric records the latter but not the
		// former.
		Usage *struct {
			PromptTokens     int64 `json:"prompt_tokens"`
			CompletionTokens int64 `json:"completion_tokens"`
			TotalTokens      int64 `json:"total_tokens"`
		} `json:"usage"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil, nil
	}

	var reasons []string
	for _, c := range resp.Choices {
		if c.FinishReason != "" {
			reasons = append(reasons, c.FinishReason)
		}
	}

	var input, output, total int64
	if resp.Usage != nil {
		input, output, total = resp.Usage.PromptTokens, resp.Usage.CompletionTokens, resp.Usage.TotalTokens
	}
	span.SetAttributes(
		semconv.GenAIResponseID(resp.ID),
		semconv.GenAIResponseModel(resp.Model),
		semconv.GenAIResponseFinishReasons(reasons),
		semconv.GenAIUsageInputTokens(input),
		semconv.GenAIUsageOutputTokens(output),
		semconv.GenAIUsageTotalTokens(total),
	)
	if resp.Usage == nil {
		return nil, nil
	}
	return &input, &output
}

// parseEmbeddingResponse sets response attributes on the span and returns the
// input token count; embeddings have no output tokens.
func parseEmbeddingResponse(body []byte, span trace.Span) (*int64, *int64) {
	var resp struct {
		Model string `json:"model"`
		Usage *struct {
			PromptTokens int64 `json:"prompt_tokens"`
			TotalTokens  int64 `json:"total_tokens"`
		} `json:"usage"`
	}
	if err := json.Unmarshal(body, &resp); err != nil {
		return nil, nil
	}

	var input, total int64
	if resp.Usage != nil {
		input, total = resp.Usage.PromptTokens, resp.Usage.TotalTokens
	}
	span.SetAttributes(
		semconv.GenAIResponseModel(resp.Model),
		semconv.GenAIUsageInputTokens(input),
		semconv.GenAIUsageTotalTokens(total),
	)
	if resp.Usage == nil {
		return nil, nil
	}
	// The embeddings response has no completion_tokens field at all, so the
	// output side is reported as absent rather than as a zero.
	return &input, nil
}

// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

// Package streaming implements the OpenAI GenAI streaming response reader
// shared by the v1, v2, and v3 openai-go instrumentation packages. It has no
// dependency on the versioned openai-go SDK, so a single copy serves all
// three; each version's own package only adapts its local operationType into
// OperationType and delegates here.
package streaming

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"sort"
	"strings"
	"sync"
	"time"

	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	otelsemconv "go.opentelemetry.io/otel/semconv/v1.37.0"
	"go.opentelemetry.io/otel/trace"
)

const (
	// ContentCaptureLimit bounds every recorded prompt or completion event. The
	// bound is deliberately well below common OTLP exporter message limits.
	ContentCaptureLimit = 16 * 1024

	truncatedContentSuffix = "... [truncated]"
)

const streamAbortedMessage = "stream aborted before completion"

// TruncateContent returns content safe to attach to a span event. The result
// is always valid UTF-8 and no larger than ContentCaptureLimit bytes.
func TruncateContent(content string) string {
	return truncateContent(content, ContentCaptureLimit)
}

func truncateContent(content string, limit int) string {
	var capturedContent contentAccumulator
	capturedContent.limit = clampContentLimit(limit)
	capturedContent.Append(content)
	return capturedContent.String()
}

// clampContentLimit normalises a caller-supplied limit into the valid range
// [len(truncatedContentSuffix), ContentCaptureLimit].
func clampContentLimit(limit int) int {
	if limit <= 0 || limit > ContentCaptureLimit {
		return ContentCaptureLimit
	}
	if limit < len(truncatedContentSuffix) {
		return len(truncatedContentSuffix)
	}
	return limit
}

// contentAccumulator retains only the content that can be exported. Once the
// limit is reached it does not retain later chunks, keeping streaming capture
// memory bounded independently of the response size.
type contentAccumulator struct {
	content   strings.Builder
	limit     int
	truncated bool
}

func (c *contentAccumulator) Append(content string) {
	if content == "" || c.truncated {
		return
	}

	contentLimit := c.limit - len(truncatedContentSuffix)
	remaining := contentLimit - c.content.Len()
	if remaining >= len(content) {
		c.content.WriteString(content)
		return
	}

	if remaining > 0 {
		c.content.WriteString(truncateToUTF8Boundary(content, remaining))
	}
	c.content.WriteString(truncatedContentSuffix)
	c.truncated = true
}

func (c *contentAccumulator) String() string {
	return c.content.String()
}

func truncateToUTF8Boundary(content string, limit int) string {
	if len(content) <= limit {
		return content
	}
	for limit > 0 && content[limit]&0xc0 == 0x80 {
		limit--
	}
	return content[:limit]
}

// OperationType identifies which OpenAI API shape a stream's chunks follow.
type OperationType int

const (
	OpChat OperationType = iota
	OpCompletion
)

type StreamingReader struct {
	reader         io.ReadCloser
	span           trace.Span
	op             OperationType
	captureContent bool
	contentLimit   int
	onDone         func()

	// mu guards every field below. A caller may Close from a goroutine other
	// than the one blocked in Read, e.g. to abort a stuck stream on a
	// timeout. Read and Close both parse and update this state, so it needs
	// a lock. The blocking read on the body itself is done without it.
	mu              sync.Mutex
	teeReader       io.Reader
	logBuffer       *bytes.Buffer
	lineBuffer      *bytes.Buffer
	done            bool
	start           time.Time
	first           time.Time
	inputTokens     int64
	outputTokens    int64
	totalTokens     int64
	id              string
	responseModel   string
	reasons         []string
	completed       bool
	capturedStreams map[int]*contentAccumulator
}

// errStreamAborted is reported when a stream is torn down (e.g. client
// cancellation or a context deadline) before a finish reason or the [DONE]
// marker was received.
var errStreamAborted = errors.New("stream aborted")

// NewStreamingReader wraps body and returns a StreamingReader that parses
// SSE chunks as they are read. contentLimit bounds the number of bytes
// retained per choice for content capture; values larger than
// ContentCaptureLimit are clamped down to that constant.
func NewStreamingReader(
	body io.ReadCloser,
	span trace.Span,
	start time.Time,
	op OperationType,
	captureContent bool,
	contentLimit int,
	onDone ...func(),
) *StreamingReader {
	var cb func()
	if len(onDone) > 0 {
		cb = onDone[0]
	}
	return &StreamingReader{
		reader:         body,
		start:          start,
		span:           span,
		op:             op,
		captureContent: captureContent,
		contentLimit:   clampContentLimit(contentLimit),
		onDone:         cb,
	}
}

func (r *StreamingReader) Read(p []byte) (n int, err error) {
	r.mu.Lock()
	if r.teeReader == nil {
		r.logBuffer = &bytes.Buffer{}
		r.lineBuffer = &bytes.Buffer{}
		r.teeReader = io.TeeReader(r.reader, r.logBuffer)
	}
	tee := r.teeReader
	r.mu.Unlock()

	// The lock is not held here. Close may run on another goroutine while
	// this call waits on the network, and it has to be able to finish first.
	n, err = tee.Read(p)

	if onDone := r.afterRead(n, err); onDone != nil {
		onDone()
	}
	return n, err
}

// afterRead parses what was just read and finalizes the stream on error. It
// returns the onDone callback when this call finalized, so the caller runs it
// after the lock is released.
func (r *StreamingReader) afterRead(n int, err error) func() {
	r.mu.Lock()
	defer r.mu.Unlock()

	if n > 0 {
		r.processSSELines()
	}
	if err == nil || r.done {
		return nil
	}
	r.done = true
	// Only a clean EOF means lineBuffer holds a complete, unterminated final
	// line. On any other read error the buffered bytes may be a truncated
	// mid-chunk fragment, so leave them unparsed.
	return r.finalize(err == io.EOF, err)
}

func (r *StreamingReader) Close() error {
	if onDone := r.finishOnClose(); onDone != nil {
		onDone()
	}

	if r.reader != nil {
		return r.reader.Close()
	}
	return nil
}

// finishOnClose finalizes the stream if nothing else has yet. It returns the
// onDone callback so the caller runs it after the lock is released.
func (r *StreamingReader) finishOnClose() func() {
	r.mu.Lock()
	defer r.mu.Unlock()

	if r.done {
		return nil
	}
	r.done = true
	// Flush the line buffer first: a caller that stops reading before EOF
	// must still get the final chunk's attributes, and the flush may itself
	// recover the finish reason or [DONE] marker. Then decide whether the
	// stream completed or was torn down prematurely.
	r.flushRemaining()
	if r.completed || len(r.reasons) > 0 {
		return r.finalize(false, nil)
	}
	return r.finalize(false, errStreamAborted)
}

// finalize ends the span and returns onDone. Call it with mu held and run the
// returned callback after unlocking, so a callback that calls Read or Close
// cannot deadlock.
func (r *StreamingReader) finalize(flush bool, err error) func() {
	if flush {
		r.flushRemaining()
	}

	// A stream is complete once a finish reason or the [DONE] marker was
	// received. It is still an error when the stream terminates with a
	// transport error (e.g. truncated chunked encoding / io.ErrUnexpectedEOF
	// after the last chunk but before [DONE]): the host application will
	// surface that error, so telemetry must record it too instead of
	// reporting a successful 200.
	completed := r.completed || len(r.reasons) > 0
	hardErr := err != nil && !errors.Is(err, io.EOF)
	if !completed || hardErr {
		if len(r.reasons) == 0 {
			r.reasons = []string{"error"}
		}
		r.span.SetStatus(codes.Error, "stream aborted")
		if hardErr {
			r.span.RecordError(err)
			r.span.SetAttributes(otelsemconv.ErrorType(err))
		}
	}
	r.span.SetAttributes(
		genAIResponseFinishReasonsKey.StringSlice(r.reasons),
		genAIUsageInputTokensKey.Int64(r.inputTokens),
		genAIUsageOutputTokensKey.Int64(r.outputTokens),
		genAIUsageTotalTokensKey.Int64(r.totalTokens),
	)
	if r.id != "" {
		r.span.SetAttributes(genAIResponseIDKey.String(r.id))
	}
	if r.responseModel != "" {
		r.span.SetAttributes(genAIResponseModelKey.String(r.responseModel))
	}
	if !r.first.IsZero() {
		firstTokenUs := r.first.Sub(r.start).Microseconds()
		r.span.SetAttributes(genAIResponseTimeToFirstTokenKey.Int64(firstTokenUs))
	}

	r.recordCapturedContent()

	r.span.End()
	return r.onDone
}

func streamError(err error) error {
	if err == io.EOF {
		return nil
	}
	return err
}

func (r *StreamingReader) recordCapturedContent() {
	if !r.captureContent || len(r.capturedStreams) == 0 {
		return
	}

	indices := make([]int, 0, len(r.capturedStreams))
	for index := range r.capturedStreams {
		indices = append(indices, index)
	}
	sort.Ints(indices)
	for _, index := range indices {
		content := r.capturedStreams[index].String()
		if content == "" {
			continue
		}
		r.span.AddEvent("gen_ai.content.completion", trace.WithAttributes(
			attribute.String("gen_ai.completion", content),
		))
	}
}

// flushRemaining parses whatever is left in lineBuffer as a final line. The
// underlying reader can report an error (typically io.EOF) right after the
// last data line, with no trailing newline to trigger processSSELines, so
// that last chunk would otherwise sit unparsed in lineBuffer forever.
func (r *StreamingReader) flushRemaining() {
	if r.lineBuffer == nil || r.lineBuffer.Len() == 0 {
		return
	}

	line := bytes.TrimSpace(r.lineBuffer.Bytes())
	r.lineBuffer.Reset()
	if len(line) == 0 {
		return
	}

	payload, done := parseSSELine(line)
	if done {
		r.completed = true
		return
	}
	if payload == nil {
		return
	}
	r.processChunk(payload)
}

func (r *StreamingReader) processSSELines() {
	if r.logBuffer == nil || r.logBuffer.Len() == 0 {
		return
	}

	data := r.logBuffer.Bytes()
	r.lineBuffer.Write(data)
	r.logBuffer.Reset()

	allData := r.lineBuffer.Bytes()
	lines := bytes.Split(allData, []byte("\n"))

	var incompleteLine []byte
	for i, line := range lines {
		if i == len(lines)-1 {
			if len(line) > 0 {
				incompleteLine = line
			}
			break
		}

		line = bytes.TrimSpace(line)
		if len(line) == 0 {
			continue
		}

		payload, done := parseSSELine(line)
		if done {
			r.completed = true
			continue
		}
		if payload != nil {
			r.processChunk(payload)
		}
	}

	r.lineBuffer.Reset()
	if len(incompleteLine) > 0 {
		r.lineBuffer.Write(incompleteLine)
	}
}

func parseSSELine(line []byte) ([]byte, bool) {
	if !bytes.HasPrefix(line, []byte("data: ")) {
		return nil, false
	}
	payload := bytes.TrimPrefix(line, []byte("data: "))
	if bytes.Equal(payload, []byte("[DONE]")) {
		return nil, true
	}
	return payload, false
}

func (r *StreamingReader) processChunk(payload []byte) {
	if r.first.IsZero() {
		r.first = time.Now()
	}

	switch r.op {
	case OpChat:
		r.processChatChunk(payload)
	case OpCompletion:
		r.processCompletionChunk(payload)
	}
}

func (r *StreamingReader) processChatChunk(payload []byte) {
	var chunk struct {
		ID      string `json:"id"`
		Model   string `json:"model"`
		Choices []struct {
			Index        *int   `json:"index"`
			FinishReason string `json:"finish_reason"`
			Delta        struct {
				Content string `json:"content"`
			} `json:"delta"`
		} `json:"choices"`
		Usage struct {
			PromptTokens     int64 `json:"prompt_tokens"`
			CompletionTokens int64 `json:"completion_tokens"`
			TotalTokens      int64 `json:"total_tokens"`
		} `json:"usage"`
	}
	if err := json.Unmarshal(payload, &chunk); err != nil {
		return
	}

	if chunk.ID != "" {
		r.id = chunk.ID
	}
	if chunk.Model != "" {
		r.responseModel = chunk.Model
	}
	if chunk.Usage.PromptTokens > 0 {
		r.inputTokens = chunk.Usage.PromptTokens
	}
	if chunk.Usage.CompletionTokens > 0 {
		r.outputTokens = chunk.Usage.CompletionTokens
	}
	if chunk.Usage.TotalTokens > 0 {
		r.totalTokens = chunk.Usage.TotalTokens
	}
	for choicePosition, c := range chunk.Choices {
		if c.FinishReason != "" {
			r.reasons = append(r.reasons, c.FinishReason)
		}
		if r.captureContent && c.Delta.Content != "" {
			r.captureChunkContent(choiceIndex(c.Index, choicePosition), c.Delta.Content)
		}
	}
}

func (r *StreamingReader) processCompletionChunk(payload []byte) {
	var chunk struct {
		ID      string `json:"id"`
		Model   string `json:"model"`
		Choices []struct {
			Index        *int   `json:"index"`
			FinishReason string `json:"finish_reason"`
			Text         string `json:"text"`
		} `json:"choices"`
		Usage struct {
			PromptTokens     int64 `json:"prompt_tokens"`
			CompletionTokens int64 `json:"completion_tokens"`
			TotalTokens      int64 `json:"total_tokens"`
		} `json:"usage"`
	}
	if err := json.Unmarshal(payload, &chunk); err != nil {
		return
	}

	if chunk.ID != "" {
		r.id = chunk.ID
	}
	if chunk.Model != "" {
		r.responseModel = chunk.Model
	}
	if chunk.Usage.PromptTokens > 0 {
		r.inputTokens = chunk.Usage.PromptTokens
	}
	if chunk.Usage.CompletionTokens > 0 {
		r.outputTokens = chunk.Usage.CompletionTokens
	}
	if chunk.Usage.TotalTokens > 0 {
		r.totalTokens = chunk.Usage.TotalTokens
	}
	for choicePosition, c := range chunk.Choices {
		if c.FinishReason != "" {
			r.reasons = append(r.reasons, c.FinishReason)
		}
		if r.captureContent && c.Text != "" {
			r.captureChunkContent(choiceIndex(c.Index, choicePosition), c.Text)
		}
	}
}

func choiceIndex(index *int, position int) int {
	if index != nil {
		return *index
	}
	return position
}

func (r *StreamingReader) captureChunkContent(index int, content string) {
	if r.capturedStreams == nil {
		r.capturedStreams = make(map[int]*contentAccumulator)
	}
	if r.capturedStreams[index] == nil {
		// The server controls the index values. Cap the map so that a stream
		// with many distinct indexes cannot grow memory without bound.
		if len(r.capturedStreams) >= 16 {
			return
		}
		r.capturedStreams[index] = &contentAccumulator{limit: r.contentLimit}
	}
	r.capturedStreams[index].Append(content)
}

// Copyright The OpenTelemetry Authors
// SPDX-License-Identifier: Apache-2.0

package v2

import (
	"context"
	"errors"
	"sync"
	"testing"

	"github.com/linode/linodego/v2"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
	"go.opentelemetry.io/otel"
	"go.opentelemetry.io/otel/attribute"
	"go.opentelemetry.io/otel/codes"
	sdkmetric "go.opentelemetry.io/otel/sdk/metric"
	"go.opentelemetry.io/otel/sdk/metric/metricdata"
	sdktrace "go.opentelemetry.io/otel/sdk/trace"
	"go.opentelemetry.io/otel/sdk/trace/tracetest"
	"go.opentelemetry.io/otel/trace"

	"go.opentelemetry.io/otelc/pkg/hook/hooktest"
)

func setupTestProviders(t *testing.T) (*tracetest.SpanRecorder, *sdkmetric.ManualReader) {
	t.Helper()
	// Reset package-level init so each test binds to the test providers.
	initOnce = sync.Once{}
	tracer = nil

	sr := tracetest.NewSpanRecorder()
	tp := sdktrace.NewTracerProvider(sdktrace.WithSpanProcessor(sr))
	otel.SetTracerProvider(tp)

	reader := sdkmetric.NewManualReader()
	mp := sdkmetric.NewMeterProvider(sdkmetric.WithReader(reader))
	otel.SetMeterProvider(mp)

	t.Cleanup(func() {
		_ = tp.Shutdown(context.Background())
		_ = mp.Shutdown(context.Background())
	})
	return sr, reader
}

func TestLinodegoEnabler(t *testing.T) {
	tests := []struct {
		name     string
		setupEnv func(t *testing.T)
		expected bool
	}{
		{
			name: "enabled explicitly",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "linodego")
			},
			expected: true,
		},
		{
			name: "disabled explicitly",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "linodego")
			},
			expected: false,
		},
		{
			name: "not in enabled list",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp")
			},
			expected: false,
		},
		{
			name:     "default enabled when no env set",
			setupEnv: func(t *testing.T) {},
			expected: true,
		},
		{
			name: "enabled with multiple instrumentations",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "nethttp,linodego,grpc")
			},
			expected: true,
		},
		{
			name: "disabled with multiple instrumentations",
			setupEnv: func(t *testing.T) {
				t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "linodego,grpc")
			},
			expected: false,
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			tt.setupEnv(t)
			assert.Equal(t, tt.expected, enabler.Enable())
		})
	}
}

func TestInstrumentationConstants(t *testing.T) {
	assert.Equal(t,
		"go.opentelemetry.io/otelc/instrumentation/github.com/linode/linodego/v2",
		instrumentationName,
	)
	assert.Equal(t, "LINODEGO", instrumentationKey)
}

func TestBeforeAfterDoRequest_Success(t *testing.T) {
	sr, reader := setupTestProviders(t)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "linodego")

	parent := context.Background()
	ictx := hooktest.NewMockHookContext(
		(*linodego.Client)(nil),
		parent,
		"GET",
		"linode/instances/1",
		nil,
		nil,
	)

	BeforeDoRequest(ictx, nil, parent, "GET", "linode/instances/1", nil, nil)

	newCtx, ok := ictx.GetParam(ctxParamIndex).(context.Context)
	require.True(t, ok)
	require.True(t, trace.SpanContextFromContext(newCtx).IsValid())

	span, ok := ictx.GetKeyData(keySpan).(trace.Span)
	require.True(t, ok)
	require.NotNil(t, span)

	AfterDoRequest(ictx, nil)

	spans := sr.Ended()
	require.Len(t, spans, 1)
	got := spans[0]
	assert.Equal(t, "GET linode/instances/1", got.Name())
	assert.Equal(t, trace.SpanKindClient, got.SpanKind())
	assert.Equal(t, codes.Unset, got.Status().Code)

	attrs := attrMap(got.Attributes())
	assert.Equal(t, "GET", attrs["http.request.method"])
	assert.Equal(t, "/linode/instances/1", attrs["url.path"])
	assert.Equal(t, "api.linode.com", attrs["server.address"])

	// doRequest does not emit metrics (operation-level only).
	var rm metricdata.ResourceMetrics
	require.NoError(t, reader.Collect(context.Background(), &rm))
	require.False(t, hasMetric(rm, "linodego.client.request.duration"))
	require.False(t, hasMetric(rm, "linodego.client.operation.duration"))
}

func TestBeforeAfterDoRequest_ErrorWithStatus(t *testing.T) {
	sr, _ := setupTestProviders(t)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "linodego")

	parent := context.Background()
	ictx := hooktest.NewMockHookContext()

	BeforeDoRequest(ictx, nil, parent, "GET", "linode/instances/999", nil, nil)
	AfterDoRequest(ictx, linodego.Error{Code: 404, Message: "Not Found"})

	spans := sr.Ended()
	require.Len(t, spans, 1)
	got := spans[0]
	assert.Equal(t, codes.Error, got.Status().Code)
	attrs := attrMap(got.Attributes())
	assert.Equal(t, int64(404), attrs["http.response.status_code"])
	assert.Equal(t, "404", attrs["error.type"])
	require.NotEmpty(t, got.Events(), "expected RecordError event")
}

func TestBeforeAfterDoRequest_PlainError(t *testing.T) {
	sr, _ := setupTestProviders(t)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "linodego")

	parent := context.Background()
	ictx := hooktest.NewMockHookContext()

	BeforeDoRequest(ictx, nil, parent, "GET", "linode/instances/1", nil, nil)
	AfterDoRequest(ictx, errors.New("network down"))

	spans := sr.Ended()
	require.Len(t, spans, 1)
	got := spans[0]
	assert.Equal(t, codes.Error, got.Status().Code)
	assert.Equal(t, "network down", got.Status().Description)
	attrs := attrMap(got.Attributes())
	assert.Equal(t, "*errors.errorString", attrs["error.type"])
}

func TestGetHostURL(t *testing.T) {
	assert.Empty(t, getHostURL(nil))

	tests := []struct {
		name string
		url  string
		want string
	}{
		{
			name: "default host",
			want: "api.linode.com",
		},
		{
			name: "custom host",
			url:  "https://my-mock-linode-api.example.com",
			want: "my-mock-linode-api.example.com",
		},
		{
			name: "custom host with port",
			url:  "https://gateway.internal:8443/v4",
			want: "gateway.internal",
		},
		{
			name: "IPv6 host with port",
			url:  "https://[::1]:8443/v4",
			want: "::1",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			c, err := linodego.NewClient(nil)
			require.NoError(t, err)
			if tt.url != "" {
				c.SetBaseURL(tt.url)
			}
			assert.Equal(t, tt.want, getHostURL(&c))
		})
	}
}

func TestBeforeAfterDoRequest_CustomServerAddress(t *testing.T) {
	sr, _ := setupTestProviders(t)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "linodego")

	c, err := linodego.NewClient(nil)
	require.NoError(t, err)
	c.SetBaseURL("https://my-mock-linode-api.example.com")

	parent := context.Background()
	ictx := hooktest.NewMockHookContext(&c, parent, "GET", "linode/instances/1", nil, nil)

	BeforeDoRequest(ictx, &c, parent, "GET", "linode/instances/1", nil, nil)
	AfterDoRequest(ictx, nil)

	spans := sr.Ended()
	require.Len(t, spans, 1)
	attrs := attrMap(spans[0].Attributes())
	assert.Equal(t, "my-mock-linode-api.example.com", attrs["server.address"])
}

func TestPublicMethodHooks_CustomServerAddress(t *testing.T) {
	sr, reader := setupTestProviders(t)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "linodego")

	c, err := linodego.NewClient(nil)
	require.NoError(t, err)
	c.SetBaseURL("https://my-mock-linode-api.example.com")

	parent := context.Background()
	ictx := hooktest.NewMockHookContext(&c, parent, 123)
	ictx.FuncName = "GetInstance"

	BeforeAPICall2(ictx, &c, parent, 123)
	AfterAPICall2(ictx, nil, nil)

	spans := sr.Ended()
	require.Len(t, spans, 1)
	attrs := attrMap(spans[0].Attributes())
	assert.Equal(t, "my-mock-linode-api.example.com", attrs["server.address"])

	var rm metricdata.ResourceMetrics
	require.NoError(t, reader.Collect(context.Background(), &rm))
	addr, ok := metricAttr(rm, "linodego.client.operation.duration", "server.address")
	require.True(t, ok, "expected server.address on operation duration metric")
	assert.Equal(t, "my-mock-linode-api.example.com", addr)
}

func TestBeforeDoRequest_Disabled(t *testing.T) {
	sr, _ := setupTestProviders(t)
	t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "linodego")

	parent := context.Background()
	ictx := hooktest.NewMockHookContext(nil, parent, "GET", "x", nil, nil)

	BeforeDoRequest(ictx, nil, parent, "GET", "x", nil, nil)
	AfterDoRequest(ictx, nil)

	assert.Empty(t, sr.Ended())
	assert.Nil(t, ictx.GetKeyData(keySpan))
}

// TestAfterDoRequest_DisabledAfterStart_Regression covers a span created while
// instrumentation was enabled and then disabled before the after hook runs. The
// span must still be ended, otherwise it leaks.
func TestAfterDoRequest_DisabledAfterStart_Regression(t *testing.T) {
	sr, _ := setupTestProviders(t)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "linodego")

	parent := context.Background()
	ictx := hooktest.NewMockHookContext(nil, parent, "GET", "linode/instances/1", nil, nil)
	BeforeDoRequest(ictx, nil, parent, "GET", "linode/instances/1", nil, nil)

	span, ok := ictx.GetKeyData(keySpan).(trace.Span)
	require.True(t, ok, "before hook should have created a span while enabled")
	require.NotNil(t, span)

	// Disable mid-operation, then run the after hook.
	t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "linodego")
	AfterDoRequest(ictx, nil)

	require.Len(t, sr.Ended(), 1, "span created by the before hook must be ended even after a mid-operation disable")
}

func TestPublicMethodHooks_Success(t *testing.T) {
	sr, reader := setupTestProviders(t)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "linodego")

	parent := context.Background()
	ictx := hooktest.NewMockHookContext(nil, parent, 123)
	ictx.FuncName = "GetInstance"

	BeforeAPICall2(ictx, nil, parent, 123)

	newCtx, ok := ictx.GetParam(1).(context.Context)
	require.True(t, ok)
	require.True(t, trace.SpanContextFromContext(newCtx).IsValid())

	AfterAPICall2(ictx, nil, nil)

	spans := sr.Ended()
	require.Len(t, spans, 1)
	got := spans[0]
	assert.Equal(t, "linodego.GetInstance", got.Name())
	assert.Equal(t, trace.SpanKindClient, got.SpanKind())
	attrs := attrMap(got.Attributes())
	assert.Equal(t, "GetInstance", attrs["code.function.name"])

	var rm metricdata.ResourceMetrics
	require.NoError(t, reader.Collect(context.Background(), &rm))
	require.True(t, hasMetric(rm, "linodego.client.operation.duration"))
	require.False(t, hasMetric(rm, "linodego.client.request.duration"))
	assert.NotContains(t, requireOperationMetricAttrs(t, reader), "error.type")
}

func TestPublicMethodHooks_Error(t *testing.T) {
	sr, reader := setupTestProviders(t)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "linodego")

	parent := context.Background()
	ictx := hooktest.NewMockHookContext(nil, parent, 999)
	ictx.FuncName = "GetInstance"

	BeforeAPICall2(ictx, nil, parent, 999)
	AfterAPICall2(ictx, nil, linodego.Error{Code: 404, Message: "Not Found"})

	spans := sr.Ended()
	require.Len(t, spans, 1)
	got := spans[0]
	assert.Equal(t, codes.Error, got.Status().Code)
	attrs := attrMap(got.Attributes())
	assert.Equal(t, int64(404), attrs["http.response.status_code"])
	assert.Equal(t, "404", attrs["error.type"])
	metricAttrs := requireOperationMetricAttrs(t, reader)
	assert.Equal(t, int64(404), metricAttrs["http.response.status_code"])
	assert.Equal(t, attrs["error.type"], metricAttrs["error.type"])
}

func TestPublicMethodHooks_PlainError(t *testing.T) {
	sr, reader := setupTestProviders(t)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "linodego")

	parent := context.Background()
	ictx := hooktest.NewMockHookContext(nil, parent, 123)
	ictx.FuncName = "GetInstance"

	BeforeAPICall2(ictx, nil, parent, 123)
	AfterAPICall2(ictx, nil, errors.New("network down"))

	spans := sr.Ended()
	require.Len(t, spans, 1)
	got := spans[0]
	assert.Equal(t, codes.Error, got.Status().Code)
	assert.Equal(t, "network down", got.Status().Description)
	attrs := attrMap(got.Attributes())
	assert.Equal(t, "*errors.errorString", attrs["error.type"])
	assert.NotContains(t, attrs, "http.response.status_code")
	metricAttrs := requireOperationMetricAttrs(t, reader)
	assert.NotContains(t, metricAttrs, "http.response.status_code")
	assert.Equal(t, attrs["error.type"], metricAttrs["error.type"])
}

func TestPublicMethodHooks_NonErrorHTTPStatusOmitsErrorType(t *testing.T) {
	sr, reader := setupTestProviders(t)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "linodego")

	ctx := context.Background()
	ictx := hooktest.NewMockHookContext(nil, ctx, 123)
	ictx.FuncName = "GetInstance"
	BeforeAPICall2(ictx, nil, ctx, 123)
	AfterAPICall2(ictx, nil, linodego.Error{Code: 200, Message: "OK"})

	spans := sr.Ended()
	require.Len(t, spans, 1)
	assert.Equal(t, codes.Unset, spans[0].Status().Code)
	assert.NotContains(t, attrMap(spans[0].Attributes()), "error.type")
	metricAttrs := requireOperationMetricAttrs(t, reader)
	assert.Equal(t, int64(200), metricAttrs["http.response.status_code"])
	assert.NotContains(t, metricAttrs, "error.type")
}

func TestPublicMethodHooks_Disabled(t *testing.T) {
	sr, _ := setupTestProviders(t)
	t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "linodego")

	ictx := hooktest.NewMockHookContext(nil, context.Background())
	ictx.FuncName = "ListRegions"
	BeforeAPICall1(ictx, nil, context.Background())
	AfterAPICall2(ictx, nil, nil)
	assert.Empty(t, sr.Ended())
}

// TestPublicMethodHooks_DisabledAfterStart_Regression covers the public-method
// path: a span created while enabled must still be ended when instrumentation is
// disabled before the after hook runs.
func TestPublicMethodHooks_DisabledAfterStart_Regression(t *testing.T) {
	sr, _ := setupTestProviders(t)
	t.Setenv("OTEL_GO_ENABLED_INSTRUMENTATIONS", "linodego")

	parent := context.Background()
	ictx := hooktest.NewMockHookContext(nil, parent, 123)
	ictx.FuncName = "GetInstance"
	BeforeAPICall2(ictx, nil, parent, 123)

	span, ok := ictx.GetKeyData(keySpan).(trace.Span)
	require.True(t, ok, "before hook should have created a span while enabled")
	require.NotNil(t, span)

	t.Setenv("OTEL_GO_DISABLED_INSTRUMENTATIONS", "linodego")
	AfterAPICall2(ictx, nil, nil)

	require.Len(t, sr.Ended(), 1, "span created by the before hook must be ended even after a mid-operation disable")
}

func attrMap(attrs []attribute.KeyValue) map[string]interface{} {
	m := make(map[string]interface{}, len(attrs))
	for _, a := range attrs {
		switch a.Value.Type() {
		case attribute.STRING:
			m[string(a.Key)] = a.Value.AsString()
		case attribute.INT64:
			m[string(a.Key)] = a.Value.AsInt64()
		default:
			m[string(a.Key)] = a.Value.AsInterface()
		}
	}
	return m
}

func hasMetric(rm metricdata.ResourceMetrics, name string) bool {
	for _, sm := range rm.ScopeMetrics {
		for _, m := range sm.Metrics {
			if m.Name == name {
				return true
			}
		}
	}
	return false
}

// metricAttr returns the string value of the given attribute key on the
// first data point of the named histogram metric.
func metricAttr(rm metricdata.ResourceMetrics, metricName, key string) (string, bool) {
	for _, sm := range rm.ScopeMetrics {
		for _, m := range sm.Metrics {
			if m.Name != metricName {
				continue
			}
			hist, ok := m.Data.(metricdata.Histogram[float64])
			if !ok {
				continue
			}
			for _, dp := range hist.DataPoints {
				if v, ok := dp.Attributes.Value(attribute.Key(key)); ok {
					return v.AsString(), true
				}
			}
		}
	}
	return "", false
}

func requireOperationMetricAttrs(t *testing.T, reader *sdkmetric.ManualReader) map[string]any {
	t.Helper()
	var rm metricdata.ResourceMetrics
	require.NoError(t, reader.Collect(context.Background(), &rm))
	for _, sm := range rm.ScopeMetrics {
		for _, m := range sm.Metrics {
			if m.Name != "linodego.client.operation.duration" {
				continue
			}
			hist, ok := m.Data.(metricdata.Histogram[float64])
			require.True(t, ok)
			require.Len(t, hist.DataPoints, 1)
			assert.Equal(t, uint64(1), hist.DataPoints[0].Count)
			return attrMap(hist.DataPoints[0].Attributes.ToSlice())
		}
	}
	t.Fatal("operation duration metric not found")
	return nil
}
